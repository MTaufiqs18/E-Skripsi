package com.example.e_skripsi.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_skripsi.R;
import com.example.e_skripsi.model.DataBimbingan;

import java.util.List;

public class DataBimbinganAdapter extends RecyclerView.Adapter<DataBimbinganAdapter.GridViewHolder>{

    private Context mCtx;
    private List<DataBimbingan> list;

    public DataBimbinganAdapter(Context mCtx, List<DataBimbingan> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    private DataBimbinganAdapter.OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(DataBimbinganAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(DataBimbingan data);
    }


    @NonNull
    @Override
    public DataBimbinganAdapter.GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_riwayat_bimbingan, viewGroup, false);
        return new GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final DataBimbinganAdapter.GridViewHolder holder, int position) {
        DataBimbingan dataBimbingan = list.get(position);

        if (dataBimbingan.getBab().equals("BAB I")){
            holder.imageView.setImageResource(R.drawable.ic_bab_i);
        } else if (dataBimbingan.getBab().equals("BAB II")){
            holder.imageView.setImageResource(R.drawable.ic_bab_ii);
        } else if (dataBimbingan.getBab().equals("BAB III")){
            holder.imageView.setImageResource(R.drawable.ic_bab_iii);
        } else if (dataBimbingan.getBab().equals("BAB IV")){
            holder.imageView.setImageResource(R.drawable.ic_bab_iv);
        } else if (dataBimbingan.getBab().equals("BAB V")){
            holder.imageView.setImageResource(R.drawable.ic_bab_v);
        }

        if (dataBimbingan.getStatus().equals("Acc")){
            holder.tvStatus.setBackgroundColor(Color.parseColor("#105913"));
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(dataBimbingan.getStatus());
        } else if (dataBimbingan.getStatus().equals("Revisi")){
            holder.tvStatus.setBackgroundColor(Color.parseColor("#D61709"));
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(dataBimbingan.getStatus());
        } else {
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(mCtx.getString(R.string.title_blm_dikoreksi));
            holder.tvStatus.setBackgroundColor(Color.parseColor("#FFC107"));
        }

        holder.tvJudul.setText(dataBimbingan.getJudul());
        holder.tvKeterangan.setText(dataBimbingan.getKeterangan());
        holder.tvWaktu.setText(dataBimbingan.getWaktu());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {;
                onItemClickCallback.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvJudul, tvKeterangan, tvWaktu, tvStatus;

        GridViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_progres);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvKeterangan = itemView.findViewById(R.id.tv_keterangan);
            tvWaktu = itemView.findViewById(R.id.tv_waktu);
            tvStatus = itemView.findViewById(R.id.tv_status);
        }
    }
}