package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.model.Dosen;
import com.example.e_skripsi.model.Mahasiswa;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    Button btLogin;
    TextInputEditText etUsername, etPassword;
    TextInputLayout tilUsername, tilPassword;
    TextView tvDaftar;
    ProgressBar progressBar;

    String newToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Objects.requireNonNull(getSupportActionBar()).hide();

        tvDaftar = findViewById(R.id.tv_daftar);
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        tilUsername = findViewById(R.id.til_username);
        tilPassword = findViewById(R.id.til_password);
        btLogin = findViewById(R.id.bt_login);
        progressBar = findViewById(R.id.progressbar);

        tvDaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegistrasiActivity.class);
                startActivity(intent);
            }
        });

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDataMhs();
            }
        });

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(LoginActivity.this,  new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                newToken = instanceIdResult.getToken();
            }
        });

        if (SharedPrefManager.getInstance(this).loginMahasiswa()) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        } else if (SharedPrefManager.getInstance(this).loginDosen()){
            Intent intent = new Intent(this, DosenActivity.class);
            startActivity(intent);
            finish();
        }
    }

    // Method untuk mengambil data mahasiswa
    private void getDataMhs(){
        final String username = Objects.requireNonNull(etUsername.getText()).toString();
        final String password = Objects.requireNonNull(etPassword.getText()).toString();

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=login_mhs",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                JSONObject objMahasiswa = obj.getJSONObject("mahasiswa");
                                SharedPrefManager.getInstance(LoginActivity.this).setMahasiswa(new Mahasiswa(
                                        objMahasiswa.getInt("npm"),
                                        objMahasiswa.getString("nama"),
                                        objMahasiswa.getString("email"),
                                        objMahasiswa.getString("telp"),
                                        objMahasiswa.getString("password"),
                                        objMahasiswa.getString("foto"),
                                        objMahasiswa.getString("judul_skripsi"),
                                        objMahasiswa.getString("pembimbing_utama"),
                                        objMahasiswa.getString("pembimbing_kedua"),
                                        objMahasiswa.getString("progres"),
                                        objMahasiswa.getString("tgl_progres")
                                ));
                                // Jika data berhasil maka akan mengupdate token
                                updateTokenMhs();
                            } else {
                                // Jika gagal inputan tidak ada dalam data mahasiswa maka memanggil method detDataDsn() untuk memeriksa
                                // inputan apakan terdapat pada data dosen
                                getDataDsn();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", username);
                params.put("password", password);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        requestQueue.add(stringRequest);
    }

    // Mengambil data dosen
    private void getDataDsn(){
        final String username = Objects.requireNonNull(etUsername.getText()).toString();
        final String password = Objects.requireNonNull(etPassword.getText()).toString();

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=login_dsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                JSONObject objMahasiswa = obj.getJSONObject("dosen");
                                SharedPrefManager.getInstance(LoginActivity.this).setDosen(new Dosen(
                                        objMahasiswa.getInt("nip"),
                                        objMahasiswa.getString("nama"),
                                        objMahasiswa.getString("email"),
                                        objMahasiswa.getString("telp"),
                                        objMahasiswa.getString("password"),
                                        objMahasiswa.getString("foto")
                                ));
                                // Jika berhasil maka akan memperbarui token pada dosen
                                updateTokenDsn();
                            } else if (obj.getString("message").equalsIgnoreCase("failed")){
                                // Jika salah maka akan menampilkan pesan salah, dalam hal ini berarti username dan password
                                // tidak ada dalam data mahasiswa maupun dosen
                                Toast.makeText(LoginActivity.this, "Email atau Password Salah", Toast.LENGTH_SHORT).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", username);
                params.put("password", password);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        requestQueue.add(stringRequest);
    }

    // Method update token mahasiswa
    public void updateTokenMhs(){

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_tokenmhs",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                // jika data mahasiswa berhasil di get dan token berhasil diperbarui maka tampilan akan berpindah ke-
                                // MainActivity sebagai halaman utama dari user mahasiswa
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", String.valueOf(SharedPrefManager.getInstance(LoginActivity.this).getMahasiswa().getNpm()));
                params.put("token", newToken);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        requestQueue.add(stringRequest);
    }

    // Method update token pada Dosen
    public void updateTokenDsn(){

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_tokendsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                // jika data dosen berhasil di get dan token berhasil diperbarui maka tampilan akan berpindah ke-
                                // DosenActivity sebagai halaman utama dari user dosen
                                Intent intent = new Intent(LoginActivity.this, DosenActivity.class);
                                startActivity(intent);
                                finish();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(LoginActivity.this).getDosen().getNip()));
                params.put("token", newToken);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        requestQueue.add(stringRequest);
    }

}
