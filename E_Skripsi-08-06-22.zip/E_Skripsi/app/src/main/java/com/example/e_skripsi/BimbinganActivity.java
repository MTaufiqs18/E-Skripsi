package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.model.Mahasiswa;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static android.text.TextUtils.isEmpty;

public class BimbinganActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView tvPilihBerkas, tvJudul;
    EditText etKeterangan,etLinkDrive;
    Spinner spDraft, spPembimbing;
    CheckBox cbPembimbingUtama, cbPembimbingKedua;
    Button btKirim;
    TextView tvLihatDraft;
    File file;
    Uri uri;

    String draft, nip_pembimbing_utama, nip_pembimbing_kedua, judul, waktu;
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=upload_bimbingan";
    String url_notifikasi = "https://dataskripsi.000webhostapp.com/e_skripsi/notifikasi/send_dosen.php";
    String url_tgl_progres = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_tgl_progres";
    String pembimbing_utama, pembimbing_kedua, tgl_progres;

    private int PICK_PDF_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bimbingan);

        if (getSupportActionBar()!=null){
            getSupportActionBar().setTitle(getString(R.string.title_bimbingan));
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
        }

        getDate();

        tvPilihBerkas = findViewById(R.id.tv_pilih_berkas);
        tvJudul = findViewById(R.id.tv_judul);
        etKeterangan = findViewById(R.id.et_keterangan);
        etLinkDrive = findViewById(R.id.et_link_drive);
        spDraft = findViewById(R.id.sp_draft);
        btKirim = findViewById(R.id.bt_kirim_draf);
        tvLihatDraft = findViewById(R.id.tv_lihat_draft);
        cbPembimbingUtama = findViewById(R.id.cb_pembimbing_utama);
        cbPembimbingKedua = findViewById(R.id.cb_pembimbing_kedua);

        judul = SharedPrefManager.getInstance(this).getMahasiswa().getJudul_skripsi();
        tvJudul.setText(judul);

        tvPilihBerkas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
            }
        });

        tvLihatDraft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uri!=null){
                    Intent intent = new Intent(BimbinganActivity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(BimbinganActivity.this, "Silahkan Pilih Berkas", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Spinner pada progres skripsi untuk memilih BAB bimbingan
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.ket_draft, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDraft.setAdapter(adapter);
        spDraft.setSelection(adapter.getPosition(draft));
        spDraft.setOnItemSelectedListener(this);

        // Mengambil data nip pembimbing dan tanggal progres dalam data SharedPreferences
        nip_pembimbing_utama = SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getPembimbing_utama();
        nip_pembimbing_kedua = SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getPembimbing_kedua();
        tgl_progres = SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getTgl_progres();

        // Tombol kirim
        btKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tgl_progres.equals("null")) {
                    // Sebelum data dikirim maka di cek inputannya terlebih dahulu pada method cekError()
                    cekError();
                    //updateTglProgres();
                } else {
                    cekError();
                }
            }
        });

    }

    //Method untuk mengambil tanggal pada device masing-masing
    private void getDate(){
        Date currentTime = Calendar.getInstance().getTime();
        @SuppressLint("SimpleDateFormat") DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        waktu = dateFormat.format(currentTime);
    }

    // Method untuk memeriksa inputan
    public void cekError(){
        // Memerika kondisi bahwa semua inputan sudah terisi, kemudian jika pembimbing pertama dan kedua dipilih
        // maka data akan dikirimkan keduanya
        if (!isEmpty(etKeterangan.getText().toString()) && uri!=null && draft!=null
                && cbPembimbingUtama.isChecked() && cbPembimbingKedua.isChecked()) {
            pembimbing_utama = cbPembimbingUtama.getText().toString().trim();
            pembimbing_kedua = cbPembimbingKedua.getText().toString().trim();
            uploadBimbinganUtama();
            uploadBimbinganKedua();
        } // Jika hanya pembimbing utama yang dipilih maka data akan dikirmkan ke pembimbing utama saja
        else if (!isEmpty(etKeterangan.getText().toString()) && uri!=null && draft!=null
                && cbPembimbingUtama.isChecked()){
            pembimbing_utama = cbPembimbingUtama.getText().toString().trim();
            uploadBimbinganUtama();
        } // Jika hanya pembimbing utama yang dipilih maka data akan dikirmkan ke pembimbing kedua saja
        else if (!isEmpty(etKeterangan.getText().toString()) && uri!=null && draft!=null
                && cbPembimbingKedua.isChecked()){
            pembimbing_kedua = cbPembimbingKedua.getText().toString().trim();
            uploadBimbinganKedua();
        } // Memerika kondisi jika tidak terdapat pembimbing kedua namun dipilih maka akan menampilkan pesan error
        else if (cbPembimbingKedua.isChecked() && nip_pembimbing_kedua == null){
            Toast.makeText(this, "Pembimbing Kedua Tidak Tersedia", Toast.LENGTH_SHORT).show();
        } // Menampilkan pesan error ketika inputan tidak terpenuhi
        else {
            Toast.makeText(this, "Semua Data Harus Diisi", Toast.LENGTH_SHORT).show();
        }
    }

    // Method untuk mengunggah data bimbingan yang ditujukan pada pembimbing pertama
    private void uploadBimbinganUtama(){

        final ProgressDialog progressDialog = new ProgressDialog(BimbinganActivity.this);
        progressDialog.setMessage("Mengirim Draft ...");
        progressDialog.show();

        InputStream iStream = null;
        try {
            iStream = getContentResolver().openInputStream(uri);
            final byte[] inputData = getBytes(iStream);
        // function untuk mengambil waktu jam
        /*Calendar calendar = Calendar.getInstance();
        final int jam = calendar.get(Calendar.HOUR_OF_DAY);
        final int menit = calendar.get(Calendar.MINUTE);*/

        final String npm = String.valueOf(SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNpm());
        final String keterangan = etKeterangan.getText().toString().trim();
        final String link_drive = etLinkDrive.getText().toString().trim();

        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));

                            if(obj.getString("message").equalsIgnoreCase("success")){
                                // Jika data berhasil diunggah maka akan memanggil method sendNotifUtama untuk
                                // mengirimkan notifikasi bimbingan pada pembimbing pertama
                                sendNotifUtama();
                                updateTglProgres();
                                Intent intent = new Intent(BimbinganActivity.this, DataBimbinganActivity.class);
                                startActivity(intent);
                                finish();
                            }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                Toast.makeText(BimbinganActivity.this, "Bimbingan Gagl Dikirim", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("nama", SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNama());
                params.put("nip", nip_pembimbing_utama);
                params.put("judul", judul);
                params.put("bab", draft);
                params.put("link_drive", link_drive);
                params.put("keterangan", keterangan);
                //params.put("waktu", waktu+"  "+jam+":"+menit+" WIB");
                params.put("waktu", waktu);

                return params;
            }
            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                params.put("file", new DataPart(npm+"_"+draft+"_"+judul+".pdf", inputData));
                return params;
            }
        };

        Volley.newRequestQueue(this).add(volleyMultipartRequest).setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method untuk mengirim bimbingan pada dosen pembimbing kedua
    private void uploadBimbinganKedua(){

        final ProgressDialog progressDialog = new ProgressDialog(BimbinganActivity.this);
        progressDialog.setMessage("Mengirim Draft ...");
        progressDialog.show();

        InputStream iStream = null;
        try {
            iStream = getContentResolver().openInputStream(uri);
            final byte[] inputData = getBytes(iStream);

            final String npm = String.valueOf(SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNpm());
            final String keterangan = etKeterangan.getText().toString().trim();
            final String link_drive = etLinkDrive.getText().toString().trim();

            VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
                    new Response.Listener<NetworkResponse>() {
                        @Override
                        public void onResponse(NetworkResponse response) {
                            progressDialog.dismiss();
                            try {
                                JSONObject obj = new JSONObject(new String(response.data));

                                if(obj.getString("message").equalsIgnoreCase("success")){
                                    sendNotifKedua();
                                    updateTglProgres();
                                    Intent intent = new Intent(BimbinganActivity.this, DataBimbinganActivity.class);
                                    startActivity(intent);
                                }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                    Toast.makeText(BimbinganActivity.this, "Bimbingan Gagl Dikirim", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                        }
                    }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("npm", npm);
                    params.put("nama", SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNama());
                    params.put("nip", nip_pembimbing_kedua);
                    params.put("judul", judul);
                    params.put("bab", draft);
                    params.put("link_drive", link_drive);
                    params.put("keterangan", keterangan);
                    //params.put("waktu", waktu+"  "+jam+":"+menit+" WIB");
                    params.put("waktu", waktu);

                    return params;
                }
                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    params.put("file", new DataPart(npm+"_"+draft+"_"+judul+".pdf", inputData));
                    return params;
                }
            };

            Volley.newRequestQueue(this).add(volleyMultipartRequest).setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method untuk mengirim notifikasi pada dospem pertama
    private void sendNotifUtama(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_notifikasi,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(BimbinganActivity.this, "Notifikasi Terkirim", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("title", SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNama());
                params.put("message", judul);
                params.put("nip", nip_pembimbing_utama);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    // Method untuk mengirim notifikasi pada dospem kedua
    private void sendNotifKedua(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_notifikasi,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(BimbinganActivity.this, "Notifikasi Terkirim", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("title", SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNama());
                params.put("message", judul);
                params.put("nip", nip_pembimbing_kedua);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    private void updateTglProgres(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_tgl_progres,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                SharedPrefManager.getInstance(BimbinganActivity.this).setMahasiswa(new Mahasiswa(
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNpm(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNama(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getEmail(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getTelp(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getPassword(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getFoto(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getJudul_skripsi(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getPembimbing_utama(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getPembimbing_kedua(),
                                        SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getProgres(),
                                        waktu
                                ));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", String.valueOf(SharedPrefManager.getInstance(BimbinganActivity.this).getMahasiswa().getNpm()));
                params.put("tgl_progres", waktu);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(BimbinganActivity.this);
        requestQueue.add(stringRequest);
    }

    // Method untuk mengubah file pdf menjadi byteArray
    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uri = data.getData();
            file= new File(Objects.requireNonNull(uri.getPath()));
            tvPilihBerkas.setText(file.getName());
        }
    }

    // Method pada Spiner
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        spDraft = (Spinner) adapterView;
        //spPembimbing = (Spinner)adapterView;
        if(spDraft.getId() == R.id.sp_draft) {
            if (adapterView.getItemAtPosition(i).equals("Pilih BAB")) {
                draft = null;
            } else {
                draft = adapterView.getItemAtPosition(i).toString();
            }
        }

    }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
