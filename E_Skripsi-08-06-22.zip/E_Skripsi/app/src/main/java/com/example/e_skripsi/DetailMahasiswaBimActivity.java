package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.e_skripsi.adapter.DataBimbinganAdapter;
import com.example.e_skripsi.adapter.ProgresAdapter;
import com.example.e_skripsi.model.DataBimbingan;
import com.example.e_skripsi.model.Mahasiswa;
import com.example.e_skripsi.model.Saran;
import com.makeramen.roundedimageview.RoundedImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class DetailMahasiswaBimActivity extends AppCompatActivity {

    public static final String PROFILE = "profil_mhs";

    RoundedImageView imgProfil;
    TextView tvNpm, tvNama, tvJudul, tvEmail, tvTelp, tvPembimbingUtama, tvPembimbingKedua, tvAwal, tvAkhir, tvProgres, tvDataKosong;
    RecyclerView recyclerView;
    Button btUpdateProgres;
    RequestOptions requestOptions = new RequestOptions();

    private List<DataBimbingan> listData = new ArrayList<>();
    private Mahasiswa mahasiswa;
    String url_image = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
    String urlWaktuAwal = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_awal_bimbingan";
    String urlWaktuAkhir = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_akhir_bimbingan";
    String url_riwayat = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=waktu_progres_bimbingan";
    String urlHapus = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_pembimbing";
    String url_update_progres = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_progres";
    String url_tgl_progres = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_tgl_progres";
    private String urlSaran = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_koreksi_bimbingan";
    private Saran saran;
    private DataBimbingan intentDataBimbingan;
    String namaDsnU, namaDsnD, progres_bimbingan, waktuAwal, waktuAkhir, progres, npm, update_progres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_mahasiswa_bim);

        Objects.requireNonNull(getSupportActionBar()).setTitle("Detail Mahasiswa");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        imgProfil = findViewById(R.id.img_profile);
        tvNpm = findViewById(R.id.tv_npm);
        tvNama = findViewById(R.id.tv_nama);
        tvJudul = findViewById(R.id.tv_judul);
        tvEmail = findViewById(R.id.tv_email);
        tvTelp = findViewById(R.id.tv_telp);
        tvPembimbingUtama = findViewById(R.id.tv_pembimbing_utama);
        tvPembimbingKedua = findViewById(R.id.tv_pembimbing_kedua);
        tvAwal = findViewById(R.id.tv_awal_bimbingan);
        tvAkhir = findViewById(R.id.tv_akhir_bimbingan);
        tvProgres = findViewById(R.id.tv_bab);
        tvDataKosong = findViewById(R.id.tv_data_kosong);
        recyclerView = findViewById(R.id.rv_riwayat);
        btUpdateProgres = findViewById(R.id.bt_update_progres);

        mahasiswa = getIntent().getParcelableExtra(PROFILE);
        assert mahasiswa != null;
        npm = String.valueOf(mahasiswa.getNpm());
        progres_bimbingan = mahasiswa.getProgres();

        if (progres_bimbingan.equals("Lulus")){
            btUpdateProgres.setVisibility(View.GONE);
        }

        btUpdateProgres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (progres_bimbingan.equals("Proposal")){
                    update_progres = "Hasil";
                } else if(progres_bimbingan.equals("Hasil")){
                    update_progres = "Sidang";
                } else if (progres_bimbingan.equals("Sidang")){
                    update_progres = "Lulus";
                }
                dialogUpdate();
                //updateTglProgres();
            }
        });

        getDataDsnU();
        getDataDsnD();
        getWaktuAkhir();
        getWaktuAwal();
        dataBimbingan();
        tampilan();

    }

    private void tampilan(){

        Glide.with(this)
                .load(url_image + mahasiswa.getFoto())
                .override(300, 300)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .apply(requestOptions)
                .into(imgProfil);
        tvNpm.setText(npm);
        tvNama.setText(mahasiswa.getNama());
        tvJudul.setText(mahasiswa.getJudul_skripsi());
        tvEmail.setText(mahasiswa.getEmail());
        tvTelp.setText(mahasiswa.getTelp());

    }

    private void getDataDsnU(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=data_dsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    namaDsnU = objDosen.getString("nama");
                                }
                                tvPembimbingUtama.setText(namaDsnU);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(mahasiswa.getPembimbing_utama()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void getDataDsnD(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=data_dsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    namaDsnD = objDosen.getString("nama");
                                }
                                tvPembimbingKedua.setText(namaDsnD);
                            } else {
                                tvPembimbingKedua.setText(R.string.nul);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(mahasiswa.getPembimbing_kedua()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void getWaktuAwal(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlWaktuAwal,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objawal = jsonArray.getJSONObject(i);
                                    waktuAwal = objawal.getString("waktu");
                                }
                                tvAwal.setText(waktuAwal);
                            } else {
                                tvAwal.setText(getString(R.string.title_blm_bimbingan));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(DetailMahasiswaBimActivity.this).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void getWaktuAkhir(){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlWaktuAkhir,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objakhir = jsonArray.getJSONObject(i);
                                    waktuAkhir = objakhir.getString("waktu");
                                    progres = objakhir.getString("bab");
                                }
                                tvAkhir.setText(waktuAkhir);
                                tvProgres.setText(progres);
                            }else {
                                tvAkhir.setText(getString(R.string.title_blm_bimbingan));
                                tvProgres.setText(getString(R.string.title_blm_bimbingan));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(DetailMahasiswaBimActivity.this).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void dataBimbingan(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_riwayat,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objBimbingan = jsonArray.getJSONObject(i);

                                    DataBimbingan dataBimbingan = new DataBimbingan(
                                            objBimbingan.getString("id"),
                                            objBimbingan.getString("npm"),
                                            objBimbingan.getString("nama"),
                                            objBimbingan.getString("nip"),
                                            objBimbingan.getString("judul"),
                                            objBimbingan.getString("bab"),
                                            objBimbingan.getString("file"),
                                            objBimbingan.getString("keterangan"),
                                            objBimbingan.getString("waktu"),
                                            objBimbingan.getString("status"),
                                            objBimbingan.getString("link_drive"),
                                            objBimbingan.getString("read")
                                    );
                                    listData.add(dataBimbingan);
                                    tvDataKosong.setVisibility(View.GONE);
                                    recyclerView.setVisibility(View.VISIBLE);
                                }
                            }else {
                                recyclerView.setVisibility(View.GONE);
                                tvDataKosong.setVisibility(View.VISIBLE);
                            }

                            recyclerView.setLayoutManager(new LinearLayoutManager(DetailMahasiswaBimActivity.this));
                            ProgresAdapter adapter = new ProgresAdapter(DetailMahasiswaBimActivity.this, listData);
                            recyclerView.setAdapter(adapter);
                            adapter.setOnItemClickCallback(new ProgresAdapter.OnItemClickCallback() {
                                @Override
                                public void onItemClicked(DataBimbingan data) {
                                    /*Intent intent = new Intent(DetailMahasiswaBimActivity.this, DetailDataBimbinganV2Activity.class);
                                    intent.putExtra(DetailDataBimbinganV2Activity.DATA_BIMBINGAN, data);
                                    startActivity(intent);*/
                                    // Jika list di klik maka akan mememanggil method saranPerbaikan(berdasarkan id)
                                    // untuk mengambil data saran/koreksi dari dosen
                                    saranPerbaikan(data.getId());
                                    intentDataBimbingan = data;
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(DetailMahasiswaBimActivity.this).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    // Method saranPerbaikan untuk mengambil data saran/koreksi dari dospem berdasarkan id bimbingan
    private void saranPerbaikan(final String id){

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Mengambil Data ...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSaran,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject objBimbingan = jsonArray.getJSONObject(i);
                                saran = new Saran(
                                        objBimbingan.getString("id"),
                                        objBimbingan.getString("npm"),
                                        objBimbingan.getString("nip"),
                                        objBimbingan.getString("judul"),
                                        objBimbingan.getString("bab"),
                                        objBimbingan.getString("file"),
                                        objBimbingan.getString("keterangan"),
                                        objBimbingan.getString("waktu"),
                                        objBimbingan.getString("status"),
                                        objBimbingan.getString("link_drive")
                                );
                            }
                            // Ketika data berhasil diambil maka akan berpindah ke tampilan Detail Data Bimbingan
                            // dengan membawa data intentDataBimbingan(data bimbingan Mahasiswa) dan data saran(data saran/koreksi dari dosen)
                            Intent intent = new Intent(DetailMahasiswaBimActivity.this, DetailDataBimbinganV2Activity.class);
                            intent.putExtra(DetailDataBimbinganV2Activity.DATA_BIMBINGAN, intentDataBimbingan);
                            intent.putExtra(DetailDataBimbinganV2Activity.DATA_SARAN, saran);
                            startActivity(intent);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    private void updateProgres(){

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Update Progres...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_update_progres,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                updateTglProgres();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("progres", update_progres);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(DetailMahasiswaBimActivity.this);
        requestQueue.add(stringRequest);
    }

    private void updateTglProgres(){

        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        final String waktu = dateFormat.format(currentTime);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_tgl_progres,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                Toast.makeText(DetailMahasiswaBimActivity.this, "Progres Berhasil Diperbarui", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(DetailMahasiswaBimActivity.this, DataMahasiswaActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", npm);
                params.put("tgl_progres", waktu);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(DetailMahasiswaBimActivity.this);
        requestQueue.add(stringRequest);
    }

    private void dialogUpdate() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        if (progres_bimbingan.equals("Sidang")){
            builder.setMessage("Apakah Mahasiswa Tersebut Sudah Lulus Sidang Skripsi ?") .setCancelable(false);
        } else {
            builder.setMessage("Apakah Mahasiswa Tersebut Sudah Melakukan Seminar "+progres_bimbingan+" ?") .setCancelable(false);
        }

        builder.setPositiveButton("Sudah", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                updateProgres();
            }
        });

        builder.setNegativeButton("Belum", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}