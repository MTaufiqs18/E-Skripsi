package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.e_skripsi.model.Mahasiswa;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProfilActivity extends AppCompatActivity {
    // Tampilan profil ini digunakan oleh user Mahasiswa dan Dosen
    TextView tvJudul, tvNpm, tvNama, tvEmail, tvTelp, tvPmbUtama, tvPmbKedua, tvTitleNpm, tvAwalBimbingan, tvAkhirBimbingan, tvProgres;
    CircleImageView imgProfile;
    LinearLayout lyPembimbingUtama, lyPembimbingKedua, lyAwalBimbingan, lyAkhirBimbingan, lyProgres;
    Button btEditProfil;

    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
    String namaDsnU, namaDsnD, images_mhs, pembimbingUtama, pembimbingKedua;
    int profilDsn;
    RequestOptions requestOptions = new RequestOptions();
    public static final String PROFIL = "profil_mhs";

    @SuppressLint("CheckResult")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        getSupportActionBar().setTitle(getString(R.string.title_profile));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        // Deklarasi variable widget terhadap id pada xml
        tvJudul = findViewById(R.id.tv_judul);
        tvNama = findViewById(R.id.tv_nama);
        tvNpm = findViewById(R.id.tv_npm);
        tvTitleNpm = findViewById(R.id.tv_title_npm);
        tvEmail = findViewById(R.id.tv_email);
        tvTelp = findViewById(R.id.tv_telp);
        tvPmbUtama = findViewById(R.id.tv_pembimbing_utama);
        tvPmbKedua = findViewById(R.id.tv_pembimbing_kedua);
        tvAwalBimbingan = findViewById(R.id.tv_awal_bimbingan);
        tvAkhirBimbingan = findViewById(R.id.tv_akhir_bimbingan);
        tvProgres = findViewById(R.id.tv_progres);
        imgProfile = findViewById(R.id.img_profile);
        lyPembimbingUtama = findViewById(R.id.ly_pembimbing_utama);
        lyPembimbingKedua = findViewById(R.id.ly_pembimbing_kedua);
        lyAwalBimbingan = findViewById(R.id.ly_awal_bimbingan);
        lyAkhirBimbingan = findViewById(R.id.ly_akhir_bimbingan);
        lyProgres = findViewById(R.id.ly_progres);
        btEditProfil = findViewById(R.id.bt_edit_profil);

        requestOptions.placeholder(R.drawable.ic_images_src);
        requestOptions.error(R.drawable.ic_images_src);
        profilDsn = getIntent().getIntExtra("profil_dsn", 0);
        images_mhs = String.valueOf(SharedPrefManager.getInstance(ProfilActivity.this).getMahasiswa().getFoto());

        // Menegcek kondisi jika nama dosen !=null dan hasil intent dari profilDsn !=nul
        // berarti pada tampilan profil yang ditampilkan adalah data profil dosen
        if (SharedPrefManager.getInstance(this).getDosen().getNama() != null || profilDsn != 0) {
            tvJudul.setVisibility(View.GONE);
            lyPembimbingUtama.setVisibility(View.GONE);
            lyPembimbingKedua.setVisibility(View.GONE);
            lyProgres.setVisibility(View.GONE);
            tvTitleNpm.setText("NIP");
            tvNpm.setText(String.valueOf(SharedPrefManager.getInstance(this).getDosen().getNip()));
            tvNama.setText(SharedPrefManager.getInstance(this).getDosen().getNama());
            tvEmail.setText(SharedPrefManager.getInstance(this).getDosen().getEmail());
            tvTelp.setText(SharedPrefManager.getInstance(this).getDosen().getTelp());
            String images_dsn = String.valueOf(SharedPrefManager.getInstance(this).getDosen().getFoto());
            Glide.with(this)
                    .load(url + images_dsn)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .apply(requestOptions)
                    .into(imgProfile);
            btEditProfil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfilActivity.this, RegistrasiActivity.class);
                    intent.putExtra("edit_profil_dsn", 1);
                    startActivity(intent);
                    finish();
                }
            });
        } // Jika data dosen == null maka akan mengecek data mahasiswa, untuk ditampilkan pada profil mahasiswa
         else {
            pembimbingUtama = SharedPrefManager.getInstance(this).getMahasiswa().getPembimbing_utama();
            pembimbingKedua = SharedPrefManager.getInstance(this).getMahasiswa().getPembimbing_kedua();
            getDataDsnU();
            getDataDsnD();
            tvJudul.setText(SharedPrefManager.getInstance(this).getMahasiswa().getJudul_skripsi());
            tvNpm.setText(String.valueOf(SharedPrefManager.getInstance(this).getMahasiswa().getNpm()));
            tvNama.setText(SharedPrefManager.getInstance(this).getMahasiswa().getNama());
            tvEmail.setText(SharedPrefManager.getInstance(this).getMahasiswa().getEmail());
            tvTelp.setText(SharedPrefManager.getInstance(this).getMahasiswa().getTelp());
            tvProgres.setText(SharedPrefManager.getInstance(this).getMahasiswa().getProgres());
            Glide.with(this)
                    .load(url + images_mhs)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true)
                    .apply(requestOptions)
                    .into(imgProfile);
            btEditProfil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ProfilActivity.this, RegistrasiActivity.class);
                    intent.putExtra("edit_profil_mhs", 1);
                    intent.putExtra("dosen_utama", namaDsnU);
                    intent.putExtra("dosen_kedua", namaDsnD);
                    intent.putExtra("nip_dsn_u", SharedPrefManager.getInstance(ProfilActivity.this).getMahasiswa().getPembimbing_utama());
                    intent.putExtra("nip_dsn_d", SharedPrefManager.getInstance(ProfilActivity.this).getMahasiswa().getPembimbing_kedua());
                    startActivity(intent);
                    finish();
                }
            });
        }

    }

    // Method untuk mengambil data dosen pembimbing utama
    private void getDataDsnU() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=data_dsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length() > 0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    namaDsnU = objDosen.getString("nama");
                                }
                                tvPmbUtama.setText(namaDsnU);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", pembimbingUtama);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ProfilActivity.this);
        requestQueue.add(stringRequest);
    }

    // Method untuk mengambil data dosen pembimbing kedua
    private void getDataDsnD() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=data_dsn",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length() > 0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    namaDsnD = objDosen.getString("nama");
                                }
                                tvPmbKedua.setText(namaDsnD);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", pembimbingKedua);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ProfilActivity.this);
        requestQueue.add(stringRequest);
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
