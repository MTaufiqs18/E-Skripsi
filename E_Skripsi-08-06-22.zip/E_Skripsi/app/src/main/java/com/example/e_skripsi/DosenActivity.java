package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.Objects;

public class DosenActivity extends AppCompatActivity {

    CardView cvBimbing, cvPesan, cvDataMahasiswa, cvProfil, cvKeluar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dosen);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_bar));

        cvBimbing = findViewById(R.id.cv_bimbing);
        cvPesan = findViewById(R.id.cv_pesan);
        cvDataMahasiswa = findViewById(R.id.cv_data_mahasiswa);
        cvProfil = findViewById(R.id.cv_profil);
        cvKeluar = findViewById(R.id.cv_keluar);

        cvBimbing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DosenActivity.this, BimbingActivityV2.class);
                startActivity(intent);
            }
        });

        cvPesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DosenActivity.this, PesanActivity.class);
                startActivity(intent);
            }
        });

        cvDataMahasiswa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DosenActivity.this, DataMahasiswaActivity.class);
                startActivity(intent);
            }
        });

        cvProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DosenActivity.this, ProfilActivity.class);
                intent.putExtra("profil_dsn", 1);
                startActivity(intent);
            }
        });

        cvKeluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogKeluar();
            }
        });

    }

    private void dialogKeluar() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda Ingin Keluar dari Aplikasi ?") .setCancelable(false);

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(DosenActivity.this, LoginActivity.class);
                startActivity(intent);
                SharedPrefManager.getInstance(DosenActivity.this).logout();
                finish();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }
}
