package com.example.e_skripsi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Toast;

import com.example.e_skripsi.databinding.ActivityDetailDataBimbinganV2Binding;
import com.example.e_skripsi.model.DataBimbingan;
import com.example.e_skripsi.model.Saran;
import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DetailDataBimbinganV2Activity extends AppCompatActivity {

    ActivityDetailDataBimbinganV2Binding binding;

    public static final int PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE = 123;
    private List<Saran> listData = new ArrayList<>();
    private Saran saran;
    public static final String DATA_BIMBINGAN = "data_bimbingan";
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/documents/";
    private String urlSaran = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_koreksi_bimbingan";
    private String id;
    String file, idSaran;
    String downloadUrl;

    public static final String DATA_SARAN = "data_saran";
    String file_saran, files_download;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDetailDataBimbinganV2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_detail));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        final DataBimbingan dataBimbingan = getIntent().getParcelableExtra(DATA_BIMBINGAN);
        saran = getIntent().getParcelableExtra(DATA_SARAN);
        //Bimbingan Mahasiswa
        if (dataBimbingan!=null){
            id = dataBimbingan.getId();
            binding.tvJudul.setText(dataBimbingan.getJudul());
            binding.tvProgres.setText(dataBimbingan.getBab());
            binding.tvKeterangan.setText(dataBimbingan.getKeterangan());
            binding.tvWaktu.setText(dataBimbingan.getWaktu());
            binding.tvDraft.setText(dataBimbingan.getFile());
            file = dataBimbingan.getFile();
            if (dataBimbingan.getStatus().equals("null")){
                binding.tvStatus.setText(getString(R.string.title_blm_dikoreksi));
                binding.lySaran.setVisibility(View.GONE);
                binding.lySaranNull.setVisibility(View.VISIBLE);
                binding.btSaran.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(DetailDataBimbinganV2Activity.this, SaranPerbaikanActivity.class);
                        intent.putExtra(DetailDataBimbinganActivity.DATA_BIMBINGAN, dataBimbingan);
                        startActivity(intent);
                    }
                });
            } else {
                binding.tvStatus.setText(dataBimbingan.getStatus());
            }
            downloadUrl = url+file;
        }

        //Saran Dosen
        if (saran!=null){
            id = saran.getId();
            binding.tvKeteranganSaran.setText(saran.getKeterangan());
            binding.tvWaktuSaran.setText(saran.getWaktu());
            binding.tvDraftSaran.setText(saran.getFile());
            binding.tvStatusSaran.setText(saran.getStatus());
            file_saran = saran.getFile();
            downloadUrl = url+file_saran;
        } else {
            binding.lySaran.setVisibility(View.GONE);
            binding.lySaranNull.setVisibility(View.VISIBLE);
            if (SharedPrefManager.getInstance(DetailDataBimbinganV2Activity.this).getDosen().getNama()!=null){
                binding.btSaran.setVisibility(View.VISIBLE);
            }
        }

        binding.ivDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dataBimbingan.getLinkDrive()!=null){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(dataBimbingan.getLinkDrive()));
                    startActivity(intent);
                } else {
                    Toast.makeText(DetailDataBimbinganV2Activity.this, "Link Google Drive Kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });

        binding.ivDriveSaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (saran.getLinkDrive()!=null){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(saran.getLinkDrive()));
                    startActivity(intent);
                } else {
                    Toast.makeText(DetailDataBimbinganV2Activity.this, "Link Google Drive Kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });

        final File pdfFile = new File(Environment.getExternalStorageDirectory() + "/E-Skripsi/" + file);
        final Uri uri = Uri.fromFile(pdfFile);
        //Bimbingan Mahasiswa
        binding.ivDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Snackbar.make(v, "File Sudah Terunduh, Silahkan Lihat Draft", Snackbar.LENGTH_SHORT).show();
                } else {
                    files_download = file;
                    dialogUnduh();
                }
            }
        });
        binding.ivViewDraft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Intent intent = new Intent(DetailDataBimbinganV2Activity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri.toString());
                    startActivity(intent);
                } else {
                    Snackbar.make(v, "Silahkan Unduh Berkas Terlebih Dahulu", Snackbar.LENGTH_SHORT).show();
                }
            }
        });
        final File pdfFile_saran = new File(Environment.getExternalStorageDirectory() + "/E-Skripsi/" + file_saran);
        final Uri uri_saran = Uri.fromFile(pdfFile_saran);
        //Saran Dosen
        binding.ivDownloadSaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile_saran.length()!=0){
                    Snackbar.make(v, "File Sudah Terunduh, Silahkan Lihat Draft", Snackbar.LENGTH_SHORT).show();
                } else {
                    files_download = file_saran;
                    dialogUnduh();
                }
            }
        });
        binding.ivViewDraftSaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile_saran.length()!=0){
                    Intent intent = new Intent(DetailDataBimbinganV2Activity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri_saran.toString());
                    startActivity(intent);
                } else {
                    Snackbar.make(v, "Silahkan Unduh Berkas Terlebih Dahulu", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void dialogUnduh() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda Ingin Mengunduh Berkas Ini ?") .setCancelable(false);

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                checkAndroidVersionCertificate();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void unduhberkas(){
        new DownloadTask(this, url+files_download);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)  private void checkPermission_Certificate() {
        if (ContextCompat.checkSelfPermission(this,  Manifest.permission.READ_EXTERNAL_STORAGE) + ContextCompat .checkSelfPermission(this,  Manifest.permission.WRITE_EXTERNAL_STORAGE)  != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale ((Activity) this, Manifest.permission.READ_EXTERNAL_STORAGE) ||  ActivityCompat.shouldShowRequestPermissionRationale ((Activity) this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                requestPermissions( new String[] {
                        Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
            } else {
                requestPermissions( new String[] {
                        Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
            }
        } else {  // write your logic code if permission already granted
            if (!downloadUrl.equalsIgnoreCase("")) {
                unduhberkas();
            }
        }
    }
    private void checkAndroidVersionCertificate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermission_Certificate();
        } else {
            if (!downloadUrl.equalsIgnoreCase("")) {
                unduhberkas();
            }
        }
    }
    @Override  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE:
                if (grantResults.length > 0) {
                    boolean writePermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean readExternalFile = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (writePermission && readExternalFile) {
                        if (!downloadUrl.equalsIgnoreCase("")) {
                            unduhberkas();
                        }
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Build.VERSION.SDK_INT >= 23 &&  !shouldShowRequestPermissionRationale(permissions[0])) {
                            Intent intent = new Intent();
                            intent.setAction(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        } else {
                            requestPermissions( new String[] {
                                    Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                            },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
                        }
                    }
                }
                break;
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }

}