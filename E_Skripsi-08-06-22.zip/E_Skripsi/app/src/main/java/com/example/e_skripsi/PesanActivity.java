package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class PesanActivity extends AppCompatActivity {

    TextView tvPesan, tvWaktu;
    EditText etPesan;
    Button btkirim;
    ProgressBar progressBar;
    LinearLayout llPesanSebelumnya;

    String nama, pesan, waktu;
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=set_pengumuman";
    String urlupdate = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_pengumuman";
    String urlget = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_pengumuman";
    String url_notifikasi_u = "https://dataskripsi.000webhostapp.com/e_skripsi/notifikasi/send_mhs_utama.php";
    String url_notifikasi_d = "https://dataskripsi.000webhostapp.com/e_skripsi/notifikasi/send_mhs_kedua.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesan);

        if (getSupportActionBar()!=null){
            getSupportActionBar().setTitle(getString(R.string.title_pesan));
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
        }

        tvPesan = findViewById(R.id.tv_pesan);
        tvWaktu = findViewById(R.id.tv_waktu);
        etPesan = findViewById(R.id.et_pesan);
        btkirim = findViewById(R.id.bt_kirim_pesan);
        progressBar = findViewById(R.id.progressbar);
        llPesanSebelumnya = findViewById(R.id.ly_pesan);

        btkirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nama!=null){
                    updatePengumuman();
                } else {
                    sendPengumuman();
                }
            }
        });

        getPengumuman();

    }

    private void sendPengumuman(){

        progressBar.setVisibility(View.VISIBLE);

        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        final String waktu = dateFormat.format(currentTime);
        final String pesan = etPesan.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {

                            JSONObject obj = new JSONObject(response);

                            if(obj.getString("message").equalsIgnoreCase("success")){
                                sendNotifU();
                                sendNotifD();
                                finish();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNip()));
                params.put("nama", SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNama());
                params.put("waktu", waktu);
                params.put("pesan", pesan);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(PesanActivity.this);
        requestQueue.add(stringRequest);
    }

    private void updatePengumuman(){

        progressBar.setVisibility(View.VISIBLE);

        Date currentTime = Calendar.getInstance().getTime();
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
        final String waktu = dateFormat.format(currentTime);
        final String pesan = etPesan.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlupdate,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {

                            JSONObject obj = new JSONObject(response);

                            if(obj.getString("message").equalsIgnoreCase("success")){
                                sendNotifU();
                                sendNotifD();
                                finish();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNip()));
                params.put("nama", SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNama());
                params.put("waktu", waktu);
                params.put("pesan", pesan);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(PesanActivity.this);
        requestQueue.add(stringRequest);
    }

    private void getPengumuman(){

        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlget,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objBimbingan = jsonArray.getJSONObject(i);

                                    nama = objBimbingan.getString("nama");
                                    pesan = objBimbingan.getString("pesan");
                                    waktu = objBimbingan.getString("waktu");

                                }
                                llPesanSebelumnya.setVisibility(View.VISIBLE);
                                tvPesan.setText(pesan);
                                tvWaktu.setText(waktu);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(PesanActivity.this));
        requestQueue.add(stringRequest);
    }

    private void sendNotifU(){
        final String pesan = etPesan.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_notifikasi_u,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(PesanActivity.this, "Pesan Berhasil Dikirim ke Mahasiswa Bimbingan", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("title", "Pak "+SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNama());
                params.put("message", pesan);
                params.put("pembimbing_utama", String.valueOf(SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNip()));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    private void sendNotifD(){
        final String pesan = etPesan.getText().toString().trim();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_notifikasi_d,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(PesanActivity.this, "Pesan Berhasil Dikirim ke Mahasiswa Bimbingan", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("title", "Pak "+SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNama());
                params.put("message", pesan);
                params.put("pembimbing_kedua", String.valueOf(SharedPrefManager.getInstance(PesanActivity.this).getDosen().getNip()));
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
