package com.example.e_skripsi.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Mahasiswa implements Parcelable {

    private int npm;
    private String nama;
    private String email;
    private String telp;
    private String password;
    private String foto;
    private String judul_skripsi;
    private String pembimbing_utama;
    private String pembimbing_kedua;
    private String progres;
    private String tgl_progres;

    public Mahasiswa(int npm, String nama, String email, String telp, String password, String foto, String judul_skripsi, String pembimbing_utama, String pembimbing_kedua, String progres, String tgl_progres) {
        this.npm = npm;
        this.nama = nama;
        this.email = email;
        this.telp = telp;
        this.password = password;
        this.foto = foto;
        this.judul_skripsi = judul_skripsi;
        this.pembimbing_utama = pembimbing_utama;
        this.pembimbing_kedua = pembimbing_kedua;
        this.progres = progres;
        this.tgl_progres = tgl_progres;
    }

    protected Mahasiswa(Parcel in) {
        npm = in.readInt();
        nama = in.readString();
        email = in.readString();
        telp = in.readString();
        password = in.readString();
        foto = in.readString();
        judul_skripsi = in.readString();
        pembimbing_utama = in.readString();
        pembimbing_kedua = in.readString();
        progres = in.readString();
        tgl_progres = in.readString();
    }

    public static final Creator<Mahasiswa> CREATOR = new Creator<Mahasiswa>() {
        @Override
        public Mahasiswa createFromParcel(Parcel in) {
            return new Mahasiswa(in);
        }

        @Override
        public Mahasiswa[] newArray(int size) {
            return new Mahasiswa[size];
        }
    };

    public int getNpm() {
        return npm;
    }

    public String getNama() {
        return nama;
    }

    public String getEmail() {
        return email;
    }

    public String getTelp() {
        return telp;
    }

    public String getPassword() {
        return password;
    }

    public String getFoto() {
        return foto;
    }

    public String getJudul_skripsi() {
        return judul_skripsi;
    }

    public String getPembimbing_utama() {
        return pembimbing_utama;
    }

    public String getPembimbing_kedua() {
        return pembimbing_kedua;
    }

    public String getProgres() {
        return progres;
    }

    public String getTgl_progres() {
        return tgl_progres;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(npm);
        dest.writeString(nama);
        dest.writeString(email);
        dest.writeString(telp);
        dest.writeString(password);
        dest.writeString(foto);
        dest.writeString(judul_skripsi);
        dest.writeString(pembimbing_utama);
        dest.writeString(pembimbing_kedua);
        dest.writeString(progres);
        dest.writeString(tgl_progres);
    }
}
