package com.example.e_skripsi.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.e_skripsi.R;
import com.example.e_skripsi.model.DataBimbingan;

import java.util.List;

public class BimbingAdapter extends RecyclerView.Adapter<BimbingAdapter.GridViewHolder>{

    private Context mCtx;
    private List<DataBimbingan> list;

    public BimbingAdapter(Context mCtx, List<DataBimbingan> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    private BimbingAdapter.OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(BimbingAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(DataBimbingan data);
    }


    @NonNull
    @Override
    public BimbingAdapter.GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        //View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_riwayat_bimbingan, viewGroup, false);\
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bimbing_v2, viewGroup, false);
        return new BimbingAdapter.GridViewHolder(view);
    }

    @SuppressLint("CheckResult")
    @Override
    public void onBindViewHolder(@NonNull final BimbingAdapter.GridViewHolder holder, int position) {
        DataBimbingan dataBimbingan = list.get(position);

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_images_src);
        requestOptions.error(R.drawable.ic_images_src);
        String url_image = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
        Glide.with(holder.itemView.getContext())
                .load(url_image +dataBimbingan.getNpm()+".png")
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .apply(requestOptions)
                .into(holder.imageView);
        holder.tvNpm.setText(dataBimbingan.getNpm()+"_"+dataBimbingan.getNama());
        holder.tvJudul.setText(dataBimbingan.getJudul());
        holder.tvWaktu.setText(dataBimbingan.getWaktu());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {;
                onItemClickCallback.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvNpm, tvJudul, tvWaktu;

        GridViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_profile);
            tvNpm = itemView.findViewById(R.id.tv_nama);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvWaktu = itemView.findViewById(R.id.tv_waktu);
        }
    }
}