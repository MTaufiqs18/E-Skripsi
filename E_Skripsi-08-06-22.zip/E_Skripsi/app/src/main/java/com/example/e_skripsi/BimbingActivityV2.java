package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.example.e_skripsi.adapter.BimbingPagerAdapter;
import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

public class BimbingActivityV2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bimbing_v2);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_bimbing));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
        getSupportActionBar().setElevation(0);

        ViewPager viewPager = findViewById(R.id.view_pager);
        TabLayout tabLayout = findViewById(R.id.tab_layout);

        BimbingPagerAdapter bimbingPagerAdapter = new BimbingPagerAdapter(this, getSupportFragmentManager());
        viewPager.setAdapter(bimbingPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}