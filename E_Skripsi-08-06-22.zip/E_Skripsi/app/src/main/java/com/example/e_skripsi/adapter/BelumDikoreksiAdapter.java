package com.example.e_skripsi.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.e_skripsi.R;
import com.example.e_skripsi.model.DataBimbingan;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BelumDikoreksiAdapter extends RecyclerView.Adapter<BelumDikoreksiAdapter.GridViewHolder>{

    private Context mCtx;
    private List<DataBimbingan> list;
    private int hari;

    public BelumDikoreksiAdapter(Context mCtx, List<DataBimbingan> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    private BelumDikoreksiAdapter.OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(BelumDikoreksiAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(DataBimbingan data);
    }


    @NonNull
    @Override
    public BelumDikoreksiAdapter.GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        //View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_riwayat_bimbingan, viewGroup, false);\
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_belum_dikoreksi, viewGroup, false);
        return new BelumDikoreksiAdapter.GridViewHolder(view);
    }

    @SuppressLint({"CheckResult", "SetTextI18n"})
    @Override
    public void onBindViewHolder(@NonNull final BelumDikoreksiAdapter.GridViewHolder holder, int position) {
        DataBimbingan dataBimbingan = list.get(position);

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_images_src);
        requestOptions.error(R.drawable.ic_images_src);
        String url_image = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
        Glide.with(holder.itemView.getContext())
                .load(url_image +dataBimbingan.getNpm()+".png")
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .apply(requestOptions)
                .into(holder.imageView);
        holder.tvNpm.setText(dataBimbingan.getNpm()+"_"+dataBimbingan.getNama());
        holder.tvJudul.setText(dataBimbingan.getJudul());
        holder.tvWaktu.setText(dataBimbingan.getWaktu());

        String strThatDay = dataBimbingan.getWaktu();
        Calendar calendar = Calendar.getInstance();

        if (strThatDay!=null){
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            Date d = null;
            try {
                d = formatter.parse(strThatDay);
                assert d != null;
                calendar.setTime(d);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 1);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Calendar today = Calendar.getInstance();
            long diff = calendar.getTimeInMillis() - today.getTimeInMillis();
            long days = (diff / (24 * 60 * 60 * 1000)) + 1;//result in millis
            hari = Integer.parseInt(String.valueOf(days))*-1;
        }

        if (dataBimbingan.getRead().equals("true")){
            holder.ivCheck.setBackgroundResource(R.drawable.ic_circle_check);
            holder.tvHari.setVisibility(View.GONE);
        } else {
            holder.ivCheck.setBackgroundResource(R.drawable.ic_circle);
            holder.tvHari.setText((hari+1) + " Hari");
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {;
                onItemClickCallback.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView, ivCheck;
        TextView tvNpm, tvJudul, tvWaktu, tvHari;

        GridViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_profile);
            tvNpm = itemView.findViewById(R.id.tv_nama);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvWaktu = itemView.findViewById(R.id.tv_waktu);
            tvHari = itemView.findViewById(R.id.tv_hari);
            ivCheck = itemView.findViewById(R.id.iv_check);
        }
    }
}