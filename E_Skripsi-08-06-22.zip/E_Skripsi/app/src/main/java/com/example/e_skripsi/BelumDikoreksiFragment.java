package com.example.e_skripsi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.adapter.BelumDikoreksiAdapter;
import com.example.e_skripsi.model.DataBimbingan;
import com.example.e_skripsi.model.Saran;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class BelumDikoreksiFragment extends Fragment {

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView tvDataKosong;
    private ProgressBar progressBar;
    private boolean loading;

    private List<DataBimbingan> listData = new ArrayList<>();
    private Saran saran;
    private DataBimbingan intentDataBimbingan;
    private String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=bimbing_v2";
    private String urlSaran = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_koreksi_bimbingan";
    private String url_update_read = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_read";
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_belum_dikoreksi, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.rc_bimbing);
        progressBar = view.findViewById(R.id.progressbar);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        tvDataKosong = view.findViewById(R.id.tv_data_kosong);

        progressDialog = new ProgressDialog(getContext());

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loading = false;
                recyclerView.setVisibility(View.GONE);
                listData.clear();
                dataBimbingan();
                new Handler().postDelayed(new Runnable() {
                    @Override public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 2000);
            }
        });

        if (loading = true){
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }

        //loading = true;
        //listData.clear();
        //dataBimbingan();

    }

    private void dataBimbingan(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objBimbingan = jsonArray.getJSONObject(i);
                                    DataBimbingan dataBimbingan = new DataBimbingan(
                                            objBimbingan.getString("id"),
                                            objBimbingan.getString("npm"),
                                            objBimbingan.getString("nama"),
                                            objBimbingan.getString("nip"),
                                            objBimbingan.getString("judul"),
                                            objBimbingan.getString("bab"),
                                            objBimbingan.getString("file"),
                                            objBimbingan.getString("keterangan"),
                                            objBimbingan.getString("waktu"),
                                            objBimbingan.getString("status"),
                                            objBimbingan.getString("link_drive"),
                                            objBimbingan.getString("read")
                                    );
                                    if (!dataBimbingan.getStatus().equals("Acc") && !dataBimbingan.getStatus().equals("Revisi")){
                                        listData.add(dataBimbingan);
                                        tvDataKosong.setVisibility(View.GONE);
                                        recyclerView.setVisibility(View.VISIBLE);
                                    }
                                }
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                tvDataKosong.setVisibility(View.VISIBLE);
                            }
                            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                            BelumDikoreksiAdapter adapter = new BelumDikoreksiAdapter(getContext(), listData);
                            recyclerView.setAdapter(adapter);
                            recyclerView.setHasFixedSize(true);
                            adapter.setOnItemClickCallback(new BelumDikoreksiAdapter.OnItemClickCallback() {
                                @Override
                                public void onItemClicked(DataBimbingan data) {
                                    // Jika list di klik maka akan mememanggil method saranPerbaikan(berdasarkan id)
                                    // untuk mengambil data saran/koreksi dari dosen
                                    if (data.getRead().equals("false")){
                                        updateRead(data.getId());
                                    } else {
                                        saranPerbaikan(data.getId());
                                    }
                                    intentDataBimbingan = data;
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", String.valueOf(SharedPrefManager.getInstance(getContext()).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(stringRequest);
    }

    // Method saranPerbaikan untuk mengambil data saran/koreksi dari dospem berdasarkan id bimbingan
    private void saranPerbaikan(final String id){

        progressDialog.setMessage("Mengambil Data ...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSaran,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject objBimbingan = jsonArray.getJSONObject(i);
                                saran = new Saran(
                                        objBimbingan.getString("id"),
                                        objBimbingan.getString("npm"),
                                        objBimbingan.getString("nip"),
                                        objBimbingan.getString("judul"),
                                        objBimbingan.getString("bab"),
                                        objBimbingan.getString("file"),
                                        objBimbingan.getString("keterangan"),
                                        objBimbingan.getString("waktu"),
                                        objBimbingan.getString("status"),
                                        objBimbingan.getString("link_drive")
                                );
                            }
                            // Ketika data berhasil diambil maka akan berpindah ke tampilan Detail Data Bimbingan
                            // dengan membawa data intentDataBimbingan(data bimbingan Mahasiswa) dan data saran(data saran/koreksi dari dosen)
                            Intent intent = new Intent(getContext(), DetailDataBimbinganV2Activity.class);
                            intent.putExtra(DetailDataBimbinganV2Activity.DATA_BIMBINGAN, intentDataBimbingan);
                            intent.putExtra(DetailDataBimbinganV2Activity.DATA_SARAN, saran);
                            startActivity(intent);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(stringRequest);
    }

    private void updateRead(final String id){

        progressDialog.setMessage("Mengambil Data ...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_update_read,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if(obj.getString("message").equalsIgnoreCase("success")){
                                saranPerbaikan(id);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }

    @Override
    public void onResume() {
        super.onResume();
        loading = true;
        listData.clear();
        dataBimbingan();
    }
}