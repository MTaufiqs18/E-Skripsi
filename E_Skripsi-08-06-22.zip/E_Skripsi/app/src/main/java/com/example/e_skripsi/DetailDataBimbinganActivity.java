package com.example.e_skripsi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.model.DataBimbingan;
import com.example.e_skripsi.model.Saran;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class DetailDataBimbinganActivity extends AppCompatActivity {

    TextView tvJudul, tvProgres, tvKeterangan, tvWaktu, tvDraft, tvStatus, tvLinkDrive;
    Button btUnduh, btLihatDraft, btSaran;

    public static final int PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE = 123;
    private List<Saran> listData = new ArrayList<>();
    private Saran saran;
    public static final String DATA_BIMBINGAN = "data_bimbingan";
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/documents/";
    private String urlSaran = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_koreksi_bimbingan";
    private String id;
    String file, idSaran;
    String downloadUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_data_bimbingan);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_detail));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        tvJudul = findViewById(R.id.tv_judul);
        tvProgres = findViewById(R.id.tv_progres);
        tvKeterangan = findViewById(R.id.tv_keterangan);
        tvWaktu = findViewById(R.id.tv_waktu);
        tvDraft = findViewById(R.id.tv_draft);
        tvStatus = findViewById(R.id.tv_status);
        tvLinkDrive = findViewById(R.id.tv_link_drive);
        btUnduh = findViewById(R.id.bt_unduh);
        btLihatDraft = findViewById(R.id.bt_lihat_draft);
        btSaran = findViewById(R.id.bt_saran);

        final DataBimbingan dataBimbingan = getIntent().getParcelableExtra(DATA_BIMBINGAN);

        if (dataBimbingan!=null){
            id = dataBimbingan.getId();
            tvJudul.setText(dataBimbingan.getJudul());
            tvProgres.setText(dataBimbingan.getBab());
            tvKeterangan.setText(dataBimbingan.getKeterangan());
            tvWaktu.setText(dataBimbingan.getWaktu());
            tvLinkDrive.setText(dataBimbingan.getLinkDrive());
            tvLinkDrive.setMovementMethod(LinkMovementMethod.getInstance());
            tvDraft.setText(dataBimbingan.getFile());
            file = dataBimbingan.getFile();
            if (dataBimbingan.getStatus().equals("null")){
                tvStatus.setText(getString(R.string.title_blm_dikoreksi));
            } else {
                tvStatus.setText(dataBimbingan.getStatus());
            }
            downloadUrl = url+file;
        }


        tvLinkDrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                assert dataBimbingan != null;
                intent.setData(Uri.parse(dataBimbingan.getLinkDrive()));
                startActivity(intent);
            }
        });

        final File pdfFile = new File(Environment.getExternalStorageDirectory() + "/E-Skripsi/" + file);
        final Uri uri = Uri.fromFile(pdfFile);

        btUnduh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Snackbar.make(v, "File Sudah Terunduh, Silahkan Lihat Draft", Snackbar.LENGTH_SHORT).show();
                } else {
                    dialogUnduh();
                }
            }
        });

        btLihatDraft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Intent intent = new Intent(DetailDataBimbinganActivity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri.toString());
                    startActivity(intent);
                } else {
                    Snackbar.make(v, "Silahkan Unduh Berkas Terlebih Dahulu", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

        saranPerbaikan();
        btSaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SharedPrefManager.getInstance(DetailDataBimbinganActivity.this).getDosen().getNama()!=null){
                    assert dataBimbingan != null;
                    if (dataBimbingan.getStatus().equals("Acc") || dataBimbingan.getStatus().equals("Revisi")){
                        Intent intent = new Intent(DetailDataBimbinganActivity.this, DetailSaranActivity.class);
                        intent.putExtra(DetailSaranActivity.DATA_SARAN, saran);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(DetailDataBimbinganActivity.this, SaranPerbaikanActivity.class);
                        intent.putExtra(DetailDataBimbinganActivity.DATA_BIMBINGAN, dataBimbingan);
                        startActivity(intent);
                        //finish();
                    }
                } else {
                    assert dataBimbingan != null;
                    if (dataBimbingan.getStatus().equals("Acc") || dataBimbingan.getStatus().equals("Revisi")){
                        Intent intent = new Intent(DetailDataBimbinganActivity.this, DetailSaranActivity.class);
                        intent.putExtra(DetailSaranActivity.DATA_SARAN, saran);
                        startActivity(intent);
                    }else {
                        Snackbar.make(v, "Skripsi Belum Dikoreksi", Snackbar.LENGTH_SHORT).show();
                    }
                }
            }
        });

        if (SharedPrefManager.getInstance(DetailDataBimbinganActivity.this).getDosen().getNama()!=null) {
            assert dataBimbingan != null;
            if (dataBimbingan.getStatus().equals("Acc") || dataBimbingan.getStatus().equals("Revisi")) {
                btSaran.setText(getString(R.string.saran_saya));
            }
        } else {
            btSaran.setText(getString(R.string.title_lihat_saran));
        }
    }

    private void saranPerbaikan(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSaran,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject objBimbingan = jsonArray.getJSONObject(i);

                                saran = new Saran(
                                        objBimbingan.getString("id"),
                                        objBimbingan.getString("npm"),
                                        objBimbingan.getString("nip"),
                                        objBimbingan.getString("judul"),
                                        objBimbingan.getString("bab"),
                                        objBimbingan.getString("file"),
                                        objBimbingan.getString("keterangan"),
                                        objBimbingan.getString("waktu"),
                                        objBimbingan.getString("status"),
                                        objBimbingan.getString("link_drive")
                                );
                                listData.add(saran);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", id);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    private void dialogUnduh() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda Ingin Mengunduh Berkas Ini ?") .setCancelable(false);

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                checkAndroidVersionCertificate();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void unduhberkas(){
        new DownloadTask(this, url+file);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)  private void checkPermission_Certificate() {
        if (ContextCompat.checkSelfPermission(this,  Manifest.permission.READ_EXTERNAL_STORAGE) + ContextCompat .checkSelfPermission(this,  Manifest.permission.WRITE_EXTERNAL_STORAGE)  != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale ((Activity) this, Manifest.permission.READ_EXTERNAL_STORAGE) ||  ActivityCompat.shouldShowRequestPermissionRationale ((Activity) this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                requestPermissions( new String[] {
                        Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
            } else {
                requestPermissions( new String[] {
                        Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
            }
        } else {  // write your logic code if permission already granted
            if (!downloadUrl.equalsIgnoreCase("")) {
                unduhberkas();
            }
        }
    }
    private void checkAndroidVersionCertificate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkPermission_Certificate();
        } else {
            if (!downloadUrl.equalsIgnoreCase("")) {
                unduhberkas();
            }
        }
    }
    @Override  public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE:
                if (grantResults.length > 0) {
                    boolean writePermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean readExternalFile = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (writePermission && readExternalFile) {
                        if (!downloadUrl.equalsIgnoreCase("")) {
                            unduhberkas();
                        }
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (Build.VERSION.SDK_INT >= 23 &&  !shouldShowRequestPermissionRationale(permissions[0])) {
                            Intent intent = new Intent();
                            intent.setAction(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        } else {
                            requestPermissions( new String[] {
                                    Manifest.permission .READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
                            },  PERMISSIONS_MULTIPLE_REQUEST_CERTIFICATE);
                        }
                    }
                }
                break;
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
