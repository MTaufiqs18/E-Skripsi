package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.model.DataBimbingan;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static android.text.TextUtils.isEmpty;

public class SaranPerbaikanActivity extends AppCompatActivity {

    TextView tvPilihBerkas, tvJudul;
    EditText etKeterangan, etLinkDrive;
    Button btKirim;
    TextView tvLihatDraft;
    ProgressBar progressBar;
    RadioGroup rgStatus;
    RadioButton rbStatus;
    File file;
    Uri uri;
    DataBimbingan dataBimbingan;
    ProgressDialog progressDialog;

    String npm, bab, id, link_drive, status, waktu;
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=set_koreksi_bimbingan";
    String url_notifikasi = "https://dataskripsi.000webhostapp.com/e_skripsi/notifikasi/send_mhs.php";

    private int PICK_PDF_REQUEST = 1;
    public static final String DATA_BIMBINGAN = "data_bimbingan";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saran_perbaikan);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_saran_perbaikan));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        tvPilihBerkas = findViewById(R.id.tv_pilih_berkas);
        tvJudul = findViewById(R.id.tv_judul);
        etKeterangan = findViewById(R.id.et_keterangan);
        etLinkDrive = findViewById(R.id.et_link_drive);
        btKirim = findViewById(R.id.bt_kirim_draf);
        tvLihatDraft = findViewById(R.id.tv_lihat_draft);
        rgStatus = findViewById(R.id.rg_status);
        progressBar = findViewById(R.id.progressbar);

        getDate();
        dataBimbingan = getIntent().getParcelableExtra(DATA_BIMBINGAN);

        if (dataBimbingan!=null){
            id = dataBimbingan.getId();
            npm = dataBimbingan.getNpm();
            bab = dataBimbingan.getBab();
            tvJudul.setText(dataBimbingan.getJudul());
        }

        tvPilihBerkas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
            }
        });

        tvLihatDraft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (uri!=null){
                    Intent intent = new Intent(SaranPerbaikanActivity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri.toString());
                    startActivity(intent);
                } else {
                    Toast.makeText(SaranPerbaikanActivity.this, "Silahkan Pilih Berkas", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = rgStatus.getCheckedRadioButtonId();
                rbStatus = findViewById(selectedId);
                cekError();
            }
        });

    }

    public void cekError(){
        if (!isEmpty(etKeterangan.getText().toString()) && uri!=null && rbStatus!=null) {
            saranPerbaikan();
        } else {
            Toast.makeText(this, "Semua Data Harus Di Isi", Toast.LENGTH_SHORT).show();
        }
    }

    //Method untuk mengambil tanggal pada device masing-masing
    private void getDate(){
        Date currentTime = Calendar.getInstance().getTime();
        @SuppressLint("SimpleDateFormat") DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        waktu = dateFormat.format(currentTime);
    }

    private void saranPerbaikan(){

        progressDialog.setMessage("Mengirim Saran ...");
        progressDialog.show();

        InputStream iStream = null;
        try {
            iStream = getContentResolver().openInputStream(uri);
            final byte[] inputData = getBytes(iStream);

            final String nip = String.valueOf(SharedPrefManager.getInstance(SaranPerbaikanActivity.this).getDosen().getNip());
            final String keterangan = etKeterangan.getText().toString().trim();
            status = rbStatus.getText().toString();
            link_drive = etLinkDrive.getText().toString();

            VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
                    new Response.Listener<NetworkResponse>() {
                        @Override
                        public void onResponse(NetworkResponse response) {
                            progressDialog.dismiss();
                            try {
                                JSONObject obj = new JSONObject(new String(response.data));
                                if(obj.getString("message").equalsIgnoreCase("success")){
                                    sendNotif();
                                }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                    Toast.makeText(SaranPerbaikanActivity.this, "Saran Perbaikan Gagal Dikirim", Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                        }
                    }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("id", id);
                    params.put("npm", npm);
                    params.put("nip", nip);
                    params.put("judul", dataBimbingan.getJudul());
                    params.put("bab", bab);
                    params.put("link_drive", link_drive);
                    params.put("keterangan", keterangan);
                    //params.put("waktu", waktu+"  "+jam+":"+menit+" WIB");
                    params.put("waktu", waktu);
                    params.put("status", status);
                    return params;
                }
                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    params.put("file", new DataPart(status+"_"+bab+"_"+dataBimbingan.getJudul()+".pdf", inputData));
                    return params;
                }
            };

            Volley.newRequestQueue(this).add(volleyMultipartRequest).setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendNotif(){

        progressDialog.setMessage("Mengirim Saran ...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_notifikasi,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        Toast.makeText(SaranPerbaikanActivity.this, "Saran Perbaikan Berhasil Dikirim", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SaranPerbaikanActivity.this, BimbingActivityV2.class);
                        startActivity(intent);
                        finish();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("title", "Pak "+SharedPrefManager.getInstance(SaranPerbaikanActivity.this).getDosen().getNama());
                params.put("message", status);
                params.put("npm", npm);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(this));
        requestQueue.add(stringRequest);
    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uri = data.getData();
            file= new File(Objects.requireNonNull(uri.getPath()));
            tvPilihBerkas.setText(file.getName());
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
