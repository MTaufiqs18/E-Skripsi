package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.adapter.DataBimbinganAdapter;
import com.example.e_skripsi.model.DataBimbingan;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    TextView tvPengumumanUtama, tvPengumumanKedua, tvPembimbingUtama, tvPembimbingKedua;
    RelativeLayout rlPengumumanSatu, rlPengumumanDua;

    String waktu, waktu2, nama, pesan, nama2, pesan2;
    int hari, hari2;

    private String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_pengumuman";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_bar));

        CardView cvBimbingan = findViewById(R.id.cv_bimbingan);
        CardView cvRiwayatBimbingan = findViewById(R.id.cv_riwayat_bimbingan);
        CardView cvProfil = findViewById(R.id.cv_profil);
        CardView cvKeluar = findViewById(R.id.cv_keluar);
        tvPembimbingUtama = findViewById(R.id.tv_pembimbing_utama);
        tvPembimbingKedua = findViewById(R.id.tv_pembimbing_kedua);
        tvPengumumanUtama = findViewById(R.id.tv_pengumuman_utama);
        tvPengumumanKedua = findViewById(R.id.tv_pengumuman_kedua);
        rlPengumumanSatu = findViewById(R.id.ly_pengumuan_satu);
        rlPengumumanDua = findViewById(R.id.ly_pengumuan_dua);

        tvPengumumanUtama.setSelected(true);
        tvPengumumanKedua.setSelected(true);

        //setOnClick pada menu Bimbingan
        cvBimbingan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, BimbinganActivity.class);
                startActivity(intent);
            }
        });

        //setOnClick pada menu Data Bimbingan
        cvRiwayatBimbingan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DataBimbinganActivity.class);
                startActivity(intent);
            }
        });

        //setOnClick pada menu Profil
        cvProfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProfilActivity.class);
                startActivity(intent);
            }
        });

        //setOnClick pada tombol Keluar
        cvKeluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogKeluar();
            }
        });

        // Pada saat memasuki halaman beranda maka langsung memnaggil method Pengumuman dari dosen pembimbing 1 dan 2
        // untuk mengambil data pengumuman dari dosen
        getPengumumanUtama();
        getPengumumanKedua();
    }

    // Method konfirmasi untuk logout user
    private void dialogKeluar() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda Ingin Keluar dari Aplikasi ?") .setCancelable(false);

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                SharedPrefManager.getInstance(MainActivity.this).logout();
                finish();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    // Method untuk mengambil data pengumuman dari pembimbing utama
    private void getPengumumanUtama(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objBimbingan = jsonArray.getJSONObject(i);

                                    nama = objBimbingan.getString("nama");
                                    pesan = objBimbingan.getString("pesan");
                                    waktu = objBimbingan.getString("waktu");
                                }
                                // Memamnggil method untuk menghitung waktu(hari) pengumuman yang dikirimkan dosen
                                // sampai hari pada saat aplikasi ini dibuka
                                hitungWaktu();

                                // Memerika pengumuman berdasarkan [hari] yang sudah dihitung pada method hitungWaktu()
                                // jika hari lebih besar atau sama dengan 3 maka pengumuman akan di sembunyikan
                                // jika kurang dari 3 maka pengumuman akan ditampilkan
                                // output dari variable hari ini menghasilkan nilai negatif jadi harus dikali -1 untuk mendapatkan nilai positif
                                if ((hari*-1)>=3){
                                    rlPengumumanSatu.setVisibility(View.GONE);
                                    tvPengumumanUtama.setVisibility(View.GONE);
                                } else {
                                    rlPengumumanSatu.setVisibility(View.VISIBLE);
                                    tvPembimbingUtama.setText("Pak "+nama);
                                    tvPengumumanUtama.setText(pesan);
                                }
                            } else {
                                rlPengumumanSatu.setVisibility(View.GONE);
                                tvPengumumanUtama.setVisibility(View.GONE);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", SharedPrefManager.getInstance(MainActivity.this).getMahasiswa().getPembimbing_utama());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(MainActivity.this));
        requestQueue.add(stringRequest);
    }

    // Method untuk mengambil pengumuman dari pembimbing ke2
    private void getPengumumanKedua(){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objBimbingan = jsonArray.getJSONObject(i);

                                    nama2 = objBimbingan.getString("nama");
                                    pesan2 = objBimbingan.getString("pesan");
                                    waktu2 = objBimbingan.getString("waktu");
                                }
                                hitungWaktu2();

                                if ((hari2*-1)>=3){
                                    rlPengumumanDua.setVisibility(View.GONE);
                                    tvPengumumanKedua.setVisibility(View.GONE);
                                } else {
                                    rlPengumumanDua.setVisibility(View.VISIBLE);
                                    tvPembimbingKedua.setText("Pak "+nama2);
                                    tvPengumumanKedua.setText(pesan2);
                                }

                            } else {
                                rlPengumumanDua.setVisibility(View.GONE);
                                tvPengumumanKedua.setVisibility(View.GONE);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", SharedPrefManager.getInstance(MainActivity.this).getMahasiswa().getPembimbing_kedua());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(MainActivity.this));
        requestQueue.add(stringRequest);
    }

    // method untuk menghitung waktu(hari) dari pengumuman oleh dosen pembimbing utama
    private void hitungWaktu(){
        String strThatDay = waktu;
        @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
        Date d = null;
        try {
            d = formatter.parse(strThatDay);//catch exception
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Calendar thatDay = Calendar.getInstance();
        thatDay.setTime(d); //rest is the same....
        Calendar today = Calendar.getInstance();
        long diff = thatDay.getTimeInMillis() - today.getTimeInMillis();
        long days = (diff / (24 * 60 * 60 * 1000)) + 1;//result in millis
        hari = Integer.parseInt(String.valueOf(days));
    }

    // method untuk menghitung waktu(hari) dari pengumuman oleh dosen pembimbing kedua
    private void hitungWaktu2(){
        String strThatDay = waktu2;
        @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
        Date d = null;
        try {
            d = formatter.parse(strThatDay);//catch exception
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Calendar thatDay = Calendar.getInstance();
        thatDay.setTime(d); //rest is the same....

        Calendar today = Calendar.getInstance();

        long diff = thatDay.getTimeInMillis() - today.getTimeInMillis();
        long days = (diff / (24 * 60 * 60 * 1000)) + 1;//result in millis
        hari2 = Integer.parseInt(String.valueOf(days));
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
    }
}
