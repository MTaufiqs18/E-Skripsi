package com.example.e_skripsi.model;

import android.os.Parcel;
import android.os.Parcelable;

public class DataBimbingan implements Parcelable {

    private String id;
    private String npm;
    private String nama;
    private String nip;
    private String judul;
    private String bab;
    private String file;
    private String keterangan;
    private String waktu;
    private String status;
    private String linkDrive;
    private String read;

    public DataBimbingan(String id, String npm, String nama, String nip, String judul, String bab, String file, String keterangan, String waktu, String status, String linkDrive, String read) {
        this.id = id;
        this.npm = npm;
        this.nama = nama;
        this.nip = nip;
        this.judul = judul;
        this.bab = bab;
        this.file = file;
        this.keterangan = keterangan;
        this.waktu = waktu;
        this.status = status;
        this.linkDrive = linkDrive;
        this.read = read;
    }

    protected DataBimbingan(Parcel in) {
        id = in.readString();
        npm = in.readString();
        nama = in.readString();
        nip = in.readString();
        judul = in.readString();
        bab = in.readString();
        file = in.readString();
        keterangan = in.readString();
        waktu = in.readString();
        status = in.readString();
        linkDrive = in.readString();
        read = in.readString();
    }

    public static final Creator<DataBimbingan> CREATOR = new Creator<DataBimbingan>() {
        @Override
        public DataBimbingan createFromParcel(Parcel in) {
            return new DataBimbingan(in);
        }

        @Override
        public DataBimbingan[] newArray(int size) {
            return new DataBimbingan[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNpm() {
        return npm;
    }

    public void setNpm(String npm) {
        this.npm = npm;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getBab() {
        return bab;
    }

    public void setBab(String bab) {
        this.bab = bab;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLinkDrive() {
        return linkDrive;
    }

    public void setLinkDrive(String linkDrive) {
        this.linkDrive = linkDrive;
    }

    public String getRead() {
        return read;
    }

    public void setRead(String read) {
        this.read = read;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(npm);
        dest.writeString(nama);
        dest.writeString(nip);
        dest.writeString(judul);
        dest.writeString(bab);
        dest.writeString(file);
        dest.writeString(keterangan);
        dest.writeString(waktu);
        dest.writeString(status);
        dest.writeString(linkDrive);
        dest.writeString(read);
    }
}
