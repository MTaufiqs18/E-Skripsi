package com.example.e_skripsi.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Dosen implements Parcelable {

    private int nip;
    private String nama;
    private String email;
    private String telp;
    private String password;
    private String foto;

    public Dosen(int nip, String nama, String email, String telp, String password, String foto) {
        this.nip = nip;
        this.nama = nama;
        this.email = email;
        this.telp = telp;
        this.password = password;
        this.foto = foto;
    }

    protected Dosen(Parcel in) {
        nip = in.readInt();
        nama = in.readString();
        email = in.readString();
        telp = in.readString();
        password = in.readString();
        foto = in.readString();
    }

    public static final Creator<Dosen> CREATOR = new Creator<Dosen>() {
        @Override
        public Dosen createFromParcel(Parcel in) {
            return new Dosen(in);
        }

        @Override
        public Dosen[] newArray(int size) {
            return new Dosen[size];
        }
    };

    public int getNip() {
        return nip;
    }

    public String getNama() {
        return nama;
    }

    public String getEmail() {
        return email;
    }

    public String getTelp() {
        return telp;
    }

    public String getPassword() {
        return password;
    }

    public String getFoto() {
        return foto;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(nip);
        dest.writeString(nama);
        dest.writeString(email);
        dest.writeString(telp);
        dest.writeString(password);
        dest.writeString(foto);
    }
}
