package com.example.e_skripsi.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Saran implements Parcelable {

    private String id;
    private String npm;
    private String nip;
    private String judul;
    private String bab;
    private String file;
    private String keterangan;
    private String waktu;
    private String status;
    private String linkDrive;

    public Saran(String id, String npm, String nip, String judul, String bab, String file, String keterangan, String waktu, String status, String linkDrive) {
        this.id = id;
        this.npm = npm;
        this.nip = nip;
        this.judul = judul;
        this.bab = bab;
        this.file = file;
        this.keterangan = keterangan;
        this.waktu = waktu;
        this.status = status;
        this.linkDrive = linkDrive;
    }

    protected Saran(Parcel in) {
        id = in.readString();
        npm = in.readString();
        nip = in.readString();
        judul = in.readString();
        bab = in.readString();
        file = in.readString();
        keterangan = in.readString();
        waktu = in.readString();
        status = in.readString();
        linkDrive = in.readString();
    }

    public static final Creator<Saran> CREATOR = new Creator<Saran>() {
        @Override
        public Saran createFromParcel(Parcel in) {
            return new Saran(in);
        }

        @Override
        public Saran[] newArray(int size) {
            return new Saran[size];
        }
    };

    public String getId() {
        return id;
    }

    public String getNpm() {
        return npm;
    }

    public String getNip() {
        return nip;
    }

    public String getJudul() {
        return judul;
    }

    public String getBab() {
        return bab;
    }

    public String getFile() {
        return file;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public String getWaktu() {
        return waktu;
    }

    public String getStatus() {
        return status;
    }

    public String getLinkDrive() {
        return linkDrive;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(npm);
        dest.writeString(nip);
        dest.writeString(judul);
        dest.writeString(bab);
        dest.writeString(file);
        dest.writeString(keterangan);
        dest.writeString(waktu);
        dest.writeString(status);
        dest.writeString(linkDrive);
    }
}
