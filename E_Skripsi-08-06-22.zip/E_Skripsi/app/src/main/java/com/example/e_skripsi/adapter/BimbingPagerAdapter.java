package com.example.e_skripsi.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.e_skripsi.AccFragment;
import com.example.e_skripsi.BelumDikoreksiFragment;
import com.example.e_skripsi.HasilFragment;
import com.example.e_skripsi.LulusFragment;
import com.example.e_skripsi.ProposalFragment;
import com.example.e_skripsi.R;
import com.example.e_skripsi.RevisiFragment;
import com.example.e_skripsi.SidangFragment;

public class BimbingPagerAdapter extends FragmentPagerAdapter {

    private final Context mContext;

    public BimbingPagerAdapter(Context context, FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mContext = context;
    }

    @StringRes
    private final int[] TAB_TITLES = new int[]{
            R.string.title_blm_dikoreksi,
            R.string.title_revisi,
            R.string.title_acc
    };
    @NonNull
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = new BelumDikoreksiFragment();
                break;
            case 1:
                fragment = new RevisiFragment();
                break;
            case 2:
                fragment = new AccFragment();
                break;
        }
        assert fragment != null;
        return fragment;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }
    @Override
    public int getCount() {
        return 3;
    }
}