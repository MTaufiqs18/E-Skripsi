package com.example.e_skripsi;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.e_skripsi.model.Dosen;
import com.example.e_skripsi.model.Mahasiswa;


public class    SharedPrefManager {
    private static final String SHARED_PREF_NAME = "FCMSharedPref";
    private static final String MHS_NPM = "mhs_npm";
    private static final String MHS_NAMA = "mhs_nama";
    private static final String MHS_EMAIL = "mhs_email";
    private static final String MHS_TELP = "mhs_telp";
    private static final String MHS_PASSWORD = "mhs_password";
    private static final String MHS_FOTO = "mhs_foto";
    private static final String MHS_JUDUL_SKRIPSI = "mhs_judul";
    private static final String MHS_PEMBIMBING_UTAMA = "mhs_pmb_utama";
    private static final String MHS_PEMBIMBING_KEDUA = "mhs_pmb_kedua";
    private static final String MHS_PROGRES = "mhs_progres";
    private static final String MHS_TGL_PROGRES = "mhs_tgl_progres";
    private static final String DSN_NIP = "dsn_nip";
    private static final String DSN_NAMA = "dsn_nama";
    private static final String DSN_EMAIL = "dsn_email";
    private static final String DSN_TELP = "dsn_telp";
    private static final String DSN_PASSWORD = "dsn_password";
    private static final String DSN_FOTO = "dsn_foto";

    private static SharedPrefManager mInstance;
    private static Context mCtx;

    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    public boolean loginMahasiswa() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(MHS_NAMA, null) != null;
    }

    public boolean loginDosen() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(DSN_NAMA, null) != null;
    }

    public void logout(){
        mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE).edit().clear().apply();
    }

    public void setMahasiswa(Mahasiswa mahasiswa) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(MHS_NPM, mahasiswa.getNpm());
        editor.putString(MHS_NAMA, mahasiswa.getNama());
        editor.putString(MHS_EMAIL, mahasiswa.getEmail());
        editor.putString(MHS_TELP, mahasiswa.getTelp());
        editor.putString(MHS_PASSWORD, mahasiswa.getPassword());
        editor.putString(MHS_FOTO, mahasiswa.getFoto());
        editor.putString(MHS_JUDUL_SKRIPSI, mahasiswa.getJudul_skripsi());
        editor.putString(MHS_PEMBIMBING_UTAMA, mahasiswa.getPembimbing_utama());
        editor.putString(MHS_PEMBIMBING_KEDUA, mahasiswa.getPembimbing_kedua());
        editor.putString(MHS_PROGRES, mahasiswa.getProgres());
        editor.putString(MHS_TGL_PROGRES, mahasiswa.getTgl_progres());
        editor.apply();
    }

    public Mahasiswa getMahasiswa() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new Mahasiswa(
                sharedPreferences.getInt(MHS_NPM, 0),
                sharedPreferences.getString(MHS_NAMA,null),
                sharedPreferences.getString(MHS_EMAIL,null),
                sharedPreferences.getString(MHS_TELP,null),
                sharedPreferences.getString(MHS_PASSWORD,null),
                sharedPreferences.getString(MHS_FOTO,null),
                sharedPreferences.getString(MHS_JUDUL_SKRIPSI, null),
                sharedPreferences.getString(MHS_PEMBIMBING_UTAMA, null),
                sharedPreferences.getString(MHS_PEMBIMBING_KEDUA, null),
                sharedPreferences.getString(MHS_PROGRES, null),
                sharedPreferences.getString(MHS_TGL_PROGRES, null)
        );
    }

    public void setDosen(Dosen dosen) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(DSN_NIP, dosen.getNip());
        editor.putString(DSN_NAMA, dosen.getNama());
        editor.putString(DSN_EMAIL, dosen.getEmail());
        editor.putString(DSN_TELP, dosen.getTelp());
        editor.putString(DSN_PASSWORD, dosen.getPassword());
        editor.putString(DSN_FOTO, dosen.getFoto());
        editor.apply();
    }

    public Dosen getDosen() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new Dosen(
                sharedPreferences.getInt(DSN_NIP, 0),
                sharedPreferences.getString(DSN_NAMA,null),
                sharedPreferences.getString(DSN_EMAIL,null),
                sharedPreferences.getString(DSN_TELP,null),
                sharedPreferences.getString(DSN_PASSWORD,null),
                sharedPreferences.getString(DSN_FOTO,null)
        );
    }
}
