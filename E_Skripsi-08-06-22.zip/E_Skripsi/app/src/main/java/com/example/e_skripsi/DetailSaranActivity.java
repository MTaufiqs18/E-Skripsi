package com.example.e_skripsi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.e_skripsi.model.Saran;
import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DetailSaranActivity extends AppCompatActivity {

    TextView tvJudul, tvProgres, tvKeterangan, tvWaktu, tvDraft, tvStatus;
    Button btUnduh, btLihatDraft;

    public static final String DATA_SARAN = "data_saran";
    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/documents/";
    String file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_saran);

        Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_saran_perbaikan));
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);

        tvJudul = findViewById(R.id.tv_judul);
        tvProgres = findViewById(R.id.tv_progres);
        tvKeterangan = findViewById(R.id.tv_keterangan);
        tvWaktu = findViewById(R.id.tv_waktu);
        tvDraft = findViewById(R.id.tv_draft);
        tvStatus = findViewById(R.id.tv_status);
        btUnduh = findViewById(R.id.bt_unduh);
        btLihatDraft = findViewById(R.id.bt_lihat_draft);

        final Saran dataBimbingan = getIntent().getParcelableExtra(DATA_SARAN);

        if (dataBimbingan!=null){
            tvJudul.setText(dataBimbingan.getJudul());
            tvProgres.setText(dataBimbingan.getBab());
            tvKeterangan.setText(dataBimbingan.getKeterangan());
            tvWaktu.setText(dataBimbingan.getWaktu());
            tvDraft.setText(dataBimbingan.getFile());
            file = dataBimbingan.getFile();
            if (dataBimbingan.getStatus().equals("null")){
                tvStatus.setText(getString(R.string.title_blm_dikoreksi));
            } else {
                tvStatus.setText(dataBimbingan.getStatus());
            }
        }

        final File pdfFile = new File(Environment.getExternalStorageDirectory() + "/E-Skripsi/" + file);
        final Uri uri = Uri.fromFile(pdfFile);

        btUnduh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Snackbar.make(v, "File Sudah Terunduh, Silahkan Lihat Draft", Snackbar.LENGTH_SHORT).show();
                } else {
                    dialogUnduh();
                }
            }
        });

        btLihatDraft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfFile.length()!=0){
                    Intent intent = new Intent(DetailSaranActivity.this, PdfViewActivity.class);
                    intent.putExtra("uri", uri.toString());
                    startActivity(intent);
                } else {
                    Snackbar.make(v, "Silahkan Unduh Berkas Terlebih Dahulu", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void dialogUnduh() {
        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("Apakah Anda Ingin Mengunduh Berkas Ini ?") .setCancelable(false);

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                unduhberkas();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    private void unduhberkas(){
        new DownloadTask(this, url+file);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
