package com.example.e_skripsi.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.e_skripsi.R;
import com.example.e_skripsi.model.DataBimbingan;

import java.util.List;

public class ProgresAdapter extends RecyclerView.Adapter<ProgresAdapter.GridViewHolder>{

    private Context mCtx;
    private List<DataBimbingan> list;

    public ProgresAdapter(Context mCtx, List<DataBimbingan> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    private ProgresAdapter.OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(ProgresAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(DataBimbingan data);
    }


    @NonNull
    @Override
    public ProgresAdapter.GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_progres, viewGroup, false);
        return new ProgresAdapter.GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ProgresAdapter.GridViewHolder holder, int position) {
        DataBimbingan dataBimbingan = list.get(position);

        if (dataBimbingan.getStatus().equals("Acc")){
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(dataBimbingan.getStatus());
        } else if (dataBimbingan.getStatus().equals("Revisi")){
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(dataBimbingan.getStatus());
        } else {
            holder.tvStatus.setVisibility(View.VISIBLE);
            holder.tvStatus.setText(mCtx.getString(R.string.title_blm_dikoreksi));
        }

        holder.tvWaktu.setText(dataBimbingan.getWaktu());
        holder.tvBab.setText(dataBimbingan.getBab());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {;
                onItemClickCallback.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        TextView tvBab, tvWaktu, tvStatus;

        GridViewHolder(View itemView) {
            super(itemView);
            tvWaktu = itemView.findViewById(R.id.tv_waktu);
            tvBab = itemView.findViewById(R.id.tv_bab);
            tvStatus = itemView.findViewById(R.id.tv_status);
        }
    }
}