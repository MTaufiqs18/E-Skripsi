package com.example.e_skripsi;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.e_skripsi.model.Dosen;
import com.example.e_skripsi.model.Mahasiswa;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;

public class RegistrasiActivity extends AppCompatActivity {

    private CircleImageView imgProfile;
    private Bitmap image;
    Button btDaftar;
    TextView tvPilihFoto, tvRegistrasi;
    Spinner spDsnU, spDsnD;
    TextInputEditText etUsername, etNama, etEmail, etTelp, etPassword, etConnfirmPassword, etJudul;
    TextInputLayout tilUsername, tilEmail, tilPassword, tilConfirmPassword, tilJudul;
    LinearLayout lyPembimbing;

    private static final int CAMERA_REQUEST = 1888;
    private String newToken;
    private String nipDsnUtama, nipDsnKedua, nmDsnU, nmDsnD;

    private final List<Dosen> listDataU = new ArrayList<>();
    private final List<Dosen> listDataD = new ArrayList<>();
    private String password, passwordMhs, passwordDsn;

    String url = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
    String url_update_mhs = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_mhs";
    String url_update_dsn = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=update_dsn";

    //Pola pembuatan password yang saat registrasi
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    @SuppressLint("CheckResult")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrasi);

        imgProfile = findViewById(R.id.img_profile);
        etUsername = findViewById(R.id.et_username);
        etNama = findViewById(R.id.et_nama);
        etEmail = findViewById(R.id.et_email);
        etTelp = findViewById(R.id.et_noTelp);
        etPassword = findViewById(R.id.et_password);
        etConnfirmPassword = findViewById(R.id.et_confirm_password);
        etJudul = findViewById(R.id.et_judul);
        tilUsername = findViewById(R.id.til_username);
        tilEmail = findViewById(R.id.til_email);
        tilPassword = findViewById(R.id.til_password);
        tilConfirmPassword = findViewById(R.id.til_confirm_password);
        tilJudul = findViewById(R.id.til_judul);
        btDaftar = findViewById(R.id.bt_daftar);
        tvPilihFoto = findViewById(R.id.tv_pilih_foto);
        tvRegistrasi = findViewById(R.id.tv_registrasi);
        spDsnU = findViewById(R.id.sp_pembimbing_utama);
        spDsnD = findViewById(R.id.sp_pembimbing_kedua);
        lyPembimbing = findViewById(R.id.ly_pembimbing);

        passwordMhs = SharedPrefManager.getInstance(this).getMahasiswa().getPassword();
        passwordDsn = SharedPrefManager.getInstance(this).getDosen().getPassword();

        //mengambil token pada device yang digunakan untuk mengirim notifikasi
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(RegistrasiActivity.this,  new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                newToken = instanceIdResult.getToken();
            }
        });

        tvPilihFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = CropImage.activity()
                        .setAspectRatio(1,1)
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .getIntent(RegistrasiActivity.this);
                startActivityForResult(intent, 100);
            }
        });

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_images_src);
        requestOptions.error(R.drawable.ic_images_src);
        int profilDosen = getIntent().getIntExtra("edit_profil_dsn", 0);
        int profilMahasiswa = getIntent().getIntExtra("edit_profil_mhs", 0);
        nmDsnU = getIntent().getStringExtra("dosen_utama");
        nmDsnD = getIntent().getStringExtra("dosen_kedua");
        nipDsnUtama = getIntent().getStringExtra("nip_dosen_u");
        nipDsnKedua = getIntent().getStringExtra("nip_dosen_d");

        //get data dosen untuk ditampilkan pada pilihan pembimbing
        data_dsn_u();
        data_dsn_d();

        // cek kondisi jika data profil dosen !=null maka tampilan ini berubah untuk edit profil dosen
        if (profilDosen !=0){
            Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_edit_profil));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            etUsername.setFocusable(false);
            tvRegistrasi.setText(R.string.title_edit_profil);
            tilPassword.setVisibility(View.GONE);
            tilConfirmPassword.setVisibility(View.GONE);
            tilJudul.setVisibility(View.GONE);
            lyPembimbing.setVisibility(View.GONE);
            etUsername.setText(String.valueOf(SharedPrefManager.getInstance(this).getDosen().getNip()));
            etNama.setText(SharedPrefManager.getInstance(this).getDosen().getNama());
            etEmail.setText(SharedPrefManager.getInstance(this).getDosen().getEmail());
            etTelp.setText(SharedPrefManager.getInstance(this).getDosen().getTelp());
            String images_dsn = String.valueOf(SharedPrefManager.getInstance(this).getDosen().getFoto());
            Glide.with(this)
                    .asBitmap()
                    .load(url + images_dsn)
                    .apply(requestOptions)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            imgProfile.setImageBitmap(resource);
                            image = resource;
                        }
                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
            btDaftar.setText(getString(R.string.bt_simpan));
            btDaftar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    update_dsn();
                }
            });
        }   // cek kondisi jika data profil mahasiswa !=null maka tampilan ini berubah untuk edit profil mahasiswa
            // jika null maka tampilan ini berfungsi sebagai fitur untuk registrasi mahasiswa
        else if (profilMahasiswa !=0){
            Objects.requireNonNull(getSupportActionBar()).setTitle(getString(R.string.title_edit_profil));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back);
            etUsername.setFocusable(false);
            etUsername.setTextColor(Color.parseColor("#8C8C8C"));
            tvRegistrasi.setText(R.string.title_edit_profil);
            tilPassword.setVisibility(View.GONE);
            tilConfirmPassword.setVisibility(View.GONE);
            etJudul.setText(SharedPrefManager.getInstance(this).getMahasiswa().getJudul_skripsi());
            etUsername.setText(String.valueOf(SharedPrefManager.getInstance(this).getMahasiswa().getNpm()));
            etNama.setText(SharedPrefManager.getInstance(this).getMahasiswa().getNama());
            etEmail.setText(SharedPrefManager.getInstance(this).getMahasiswa().getEmail());
            etTelp.setText(SharedPrefManager.getInstance(this).getMahasiswa().getTelp());

            String images_mhs = String.valueOf(SharedPrefManager.getInstance(this).getMahasiswa().getFoto());
            Glide.with(this)
                    .asBitmap()
                    .load(url + images_mhs)
                    .apply(requestOptions)
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            imgProfile.setImageBitmap(resource);
                            image = resource;
                        }
                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                        }
                    });
            btDaftar.setText(getString(R.string.bt_simpan));
            btDaftar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    update_mhs();
                }
            });
        } else {
            Objects.requireNonNull(getSupportActionBar()).hide();
            btDaftar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    confirmInput();
                }
            });
        }

    }

    // method untuk memvalidasi inputan email harus sesuai(example@email.com) dan tidak boleh kosong
    private boolean validateEmail() {
        String emailInput = tilEmail.getEditText().getText().toString().trim();
        if (emailInput.isEmpty()) {
            tilEmail.setError("Kolom Tidak Boleh Kosong");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            tilEmail.setError("Masukkan Email Dengan Benar");
            return false;
        } else {
            tilEmail.setError(null);
            return true;
        }
    }

    // method untuk memvalidasi inputan password apakah sesuai dengan pola yang sudah ditentukan dan password tidak boleh kosong
    private boolean validatePassword() {
        String passwordInput = tilPassword.getEditText().getText().toString().trim();
        if (passwordInput.isEmpty()) {
            tilPassword.setError("Kolom Tidak Boleh Kosong");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            tilPassword.setError("Password Terlalu Pendek");
            return false;
        } else {
            tilPassword.setError(null);
            return true;
        }
    }

    // method untuk memeriksa validasi password itu sama dengan password sebelumnya
    private boolean validateConfirmPassword() {
        String passwordInput = tilPassword.getEditText().getText().toString().trim();
        String confirmPasswordInput = tilConfirmPassword.getEditText().getText().toString().trim();
        if (!passwordInput.equals(confirmPasswordInput)) {
            tilConfirmPassword.setError("Password Tidak Sama");
            return false;
        } else if (!PASSWORD_PATTERN.matcher(passwordInput).matches()) {
            tilPassword.setError("Password Terlalu Pendek");
            return false;
        } else {
            tilConfirmPassword.setError(null);
            return true;
        }
    }

    // method ini digunakan untuk mengkonfirmasi semua form inputan harus benar2 terisi semua
    public void confirmInput() {
        String username = tilUsername.getEditText().getText().toString().trim();
        String judul = tilJudul.getEditText().getText().toString().trim();
        if (!validateEmail() | !validatePassword() | !validateConfirmPassword() | username.isEmpty() | judul.isEmpty() | image==null | nipDsnUtama.equals("0")) {
            Toast.makeText(this, "Semua Data Harus Diisi", Toast.LENGTH_SHORT).show();
        }else {
            // jika semua sudah terisi maka akan memanggil method prosesRegister() untuk mengirim data ke server
            prosesRegister();
        }
    }

    // method ini digunakan untuk mengirim data inputan ke server dengan menggunakan library volley
    private void prosesRegister() {

        final String username = etUsername.getText().toString().trim();
        final String nama = etNama.getText().toString().trim();
        final String email = etEmail.getText().toString().trim();
        final String noTelp = etTelp.getText().toString().trim();
        final String judul = etJudul.getText().toString().trim();
        final String password = etPassword.getText().toString().trim();

        final ProgressDialog progressDialog = new ProgressDialog(RegistrasiActivity.this);
        progressDialog.setMessage("Proses Daftar...");
        progressDialog.show();

        if (newToken == null) {
            progressDialog.dismiss();
            Toast.makeText(this, "Token not generated", Toast.LENGTH_LONG).show();
            return;
        }
        // Link API ada yg warna ijo untuk registrasi
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=registrasi",
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));

                            if(obj.getString("message").equalsIgnoreCase("success")){

                                Toast.makeText(RegistrasiActivity.this, "Registrasi Berhasil, Silahkan Login", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(RegistrasiActivity.this, LoginActivity.class));
                                finish();

                            }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                Toast.makeText(RegistrasiActivity.this, "Username Sudah Terdaftar", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", username);
                params.put("nama", nama);
                params.put("email", email);
                params.put("telp", noTelp);
                params.put("password", password);
                params.put("token", newToken);
                params.put("judul_skripsi", judul);
                params.put("pembimbing_utama", nipDsnUtama);
                params.put("pembimbing_kedua", nipDsnKedua);
                return params;
            }
            @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();
                    params.put("foto", new DataPart(username+".png", getFileDataFromDrawable(image)));
                    return params;
                }
        };
        Volley.newRequestQueue(this).add(volleyMultipartRequest)
                .setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    private void data_dsn_u(){

        final ProgressDialog progressDialog = new ProgressDialog(RegistrasiActivity.this);
        progressDialog.setMessage("Mengambil Data...");
        progressDialog.show();

        String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_all_dsn";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    Dosen dosen = new Dosen(
                                            objDosen.getInt("nip"),
                                            objDosen.getString("nama"),
                                            objDosen.getString("email"),
                                            objDosen.getString("telp"),
                                            password,
                                            objDosen.getString("foto")
                                    );
                                    listDataU.add(dosen);
                                }
                            }

                            final ArrayList<String> dataDosen = new ArrayList<>();
                            for (int i = 0; i<listDataU.size();i++){
                                dataDosen.add(listDataU.get(i).getNama());
                            }

                            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(RegistrasiActivity.this, android.R.layout.simple_spinner_dropdown_item, dataDosen);
                            spDsnU.setAdapter(dataAdapter);
                            spDsnU.setSelection(dataAdapter.getPosition(nmDsnU));
                            spDsnU.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    nipDsnUtama = String.valueOf(listDataU.get(i).getNip());
                                }
                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {
                                }
                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                    }
                }) ;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(RegistrasiActivity.this));
        requestQueue.add(stringRequest);
    }

    private void data_dsn_d(){

        String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_all_dsn";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objDosen = jsonArray.getJSONObject(i);
                                    Dosen dosen = new Dosen(
                                            objDosen.getInt("nip"),
                                            objDosen.getString("nama"),
                                            objDosen.getString("email"),
                                            objDosen.getString("telp"),
                                            password,
                                            objDosen.getString("foto")
                                    );
                                    listDataD.add(dosen);
                                }
                            }

                            final ArrayList<String> dataDosen = new ArrayList<>();
                            for (int i = 0; i<listDataD.size();i++){
                                dataDosen.add(listDataD.get(i).getNama());
                            }

                            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(RegistrasiActivity.this, android.R.layout.simple_spinner_dropdown_item, dataDosen);
                            spDsnD.setAdapter(dataAdapter);
                            spDsnD.setSelection(dataAdapter.getPosition(nmDsnD));
                            spDsnD.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    nipDsnKedua = String.valueOf(listDataD.get(i).getNip());
                                }
                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {
                                }
                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }) ;
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(RegistrasiActivity.this));
        requestQueue.add(stringRequest);
    }

    // method ini digunakan untuk mengirim update data dari profil mahasiswa
    private void update_mhs(){

        final String username = etUsername.getText().toString().trim();
        final String nama = etNama.getText().toString().trim();
        final String email = etEmail.getText().toString().trim();
        final String noTelp = etTelp.getText().toString().trim();
        final String judul = etJudul.getText().toString().trim();

        final ProgressDialog progressDialog = new ProgressDialog(RegistrasiActivity.this);
        progressDialog.setMessage("Memperbarui Profil...");
        progressDialog.show();

        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url_update_mhs,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));

                            if(obj.getString("message").equalsIgnoreCase("success")){
                                JSONObject objMahasiswa = obj.getJSONObject("mahasiswa");
                                SharedPrefManager.getInstance(RegistrasiActivity.this).setMahasiswa(new Mahasiswa(
                                        objMahasiswa.getInt("npm"),
                                        objMahasiswa.getString("nama"),
                                        objMahasiswa.getString("email"),
                                        objMahasiswa.getString("telp"),
                                        passwordMhs,
                                        objMahasiswa.getString("foto"),
                                        objMahasiswa.getString("judul_skripsi"),
                                        objMahasiswa.getString("pembimbing_utama"),
                                        objMahasiswa.getString("pembimbing_kedua"),
                                        objMahasiswa.getString("progres"),
                                        objMahasiswa.getString("tgl_progres")
                                ));

                                Toast.makeText(RegistrasiActivity.this, "Profil Berhasil Diperbarui", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegistrasiActivity.this, ProfilActivity.class);
                                startActivity(intent);
                                finish();
                            }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                Toast.makeText(RegistrasiActivity.this, "Profil Gagal Diperbarui", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("npm", username);
                params.put("nama", nama);
                params.put("email", email);
                params.put("telp", noTelp);
                params.put("judul_skripsi", judul);
                params.put("pembimbing_utama", nipDsnUtama);
                params.put("pembimbing_kedua", nipDsnKedua);
                return params;
            }
            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                params.put("foto", new DataPart(username+".png", getFileDataFromDrawable(image)));
                return params;
            }
        };
        Volley.newRequestQueue(this).add(volleyMultipartRequest)
                .setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    // method ini digunakan untuk mengirim update data dari profil dosen
    private void update_dsn(){

        final String username = etUsername.getText().toString().trim();
        final String nama = etNama.getText().toString().trim();
        final String email = etEmail.getText().toString().trim();
        final String noTelp = etTelp.getText().toString().trim();

        final ProgressDialog progressDialog = new ProgressDialog(RegistrasiActivity.this);
        progressDialog.setMessage("Memperbarui Profil...");
        progressDialog.show();

        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url_update_dsn,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));

                            if(obj.getString("message").equalsIgnoreCase("success")){
                                JSONObject objMahasiswa = obj.getJSONObject("dosen");
                                SharedPrefManager.getInstance(RegistrasiActivity.this).setDosen(new Dosen(
                                        objMahasiswa.getInt("nip"),
                                        objMahasiswa.getString("nama"),
                                        objMahasiswa.getString("email"),
                                        objMahasiswa.getString("telp"),
                                        passwordDsn,
                                        objMahasiswa.getString("foto")
                                ));

                                Toast.makeText(RegistrasiActivity.this, "Profil Berhasil Diperbarui", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegistrasiActivity.this, ProfilActivity.class);
                                intent.putExtra("profil_dsn", 1);
                                startActivity(intent);
                                finish();
                            }else if(obj.getString("message").equalsIgnoreCase("failed")){
                                Toast.makeText(RegistrasiActivity.this, "Profil Gagal Diperbarui", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nip", username);
                params.put("nama", nama);
                params.put("email", email);
                params.put("telp", noTelp);
                return params;
            }
            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                params.put("foto", new DataPart(username+".png", getFileDataFromDrawable(image)));
                return params;
            }
        };
        Volley.newRequestQueue(this).add(volleyMultipartRequest)
                .setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    // method ini digunakan untuk mengkonversi gambar menjadi satuan byteArray untuk bisa dikirim ke server
    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    // method ini dipanggil untuk menampilkan hasil data dari intent file manager/galeri ketika mengambil foto ataupun dari apilkasi kamera
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imgProfile.setImageBitmap(photo);
            image = photo;
        }

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            Uri imageUri = result.getUri();
            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                image = bitmap;
                imgProfile.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
