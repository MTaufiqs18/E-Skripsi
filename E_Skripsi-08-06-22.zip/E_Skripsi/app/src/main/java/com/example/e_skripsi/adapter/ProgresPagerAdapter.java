package com.example.e_skripsi.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.e_skripsi.HasilFragment;
import com.example.e_skripsi.LulusFragment;
import com.example.e_skripsi.ProposalFragment;
import com.example.e_skripsi.R;
import com.example.e_skripsi.SidangFragment;

public class ProgresPagerAdapter extends FragmentPagerAdapter {

    private final Context mContext;

    public ProgresPagerAdapter(Context context, FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mContext = context;
    }

    @StringRes
    private final int[] TAB_TITLES = new int[]{
            R.string.title_proposal,
            R.string.title_hasil,
            R.string.title_sidang,
            R.string.title_lulus
    };
    @NonNull
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = new ProposalFragment();
                break;
            case 1:
                fragment = new HasilFragment();
                break;
            case 2:
                fragment = new SidangFragment();
                break;
            case 3:
                fragment = new LulusFragment();
                break;
        }
        assert fragment != null;
        return fragment;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }
    @Override
    public int getCount() {
        return 4;
    }
}