package com.example.e_skripsi.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.e_skripsi.R;
import com.example.e_skripsi.model.Mahasiswa;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MahasiswaAdapter extends RecyclerView.Adapter<MahasiswaAdapter.GridViewHolder>{

    private Context mCtx;
    private List<Mahasiswa> list;
    private Bitmap bitmap;
    int hari;

    public MahasiswaAdapter(Context mCtx, List<Mahasiswa> list) {
        this.mCtx = mCtx;
        this.list = list;
    }

    private MahasiswaAdapter.OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(MahasiswaAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(Mahasiswa data);
    }


    @NonNull
    @Override
    public MahasiswaAdapter.GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_bimbing, viewGroup, false);
        return new MahasiswaAdapter.GridViewHolder(view);
    }

    @SuppressLint("CheckResult")
    @Override
    public void onBindViewHolder(@NonNull final MahasiswaAdapter.GridViewHolder holder, int position) {
        Mahasiswa mahasiswa = list.get(position);

        String strThatDay = mahasiswa.getTgl_progres();
        Calendar calendar = Calendar.getInstance();

        if (strThatDay!=null){
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
            @SuppressLint("SimpleDateFormat") DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
            Date d = null;
            try {
                d = formatter.parse(strThatDay);
                assert d != null;
                calendar.setTime(d);
                calendar.set(Calendar.HOUR_OF_DAY, 0);
                calendar.set(Calendar.MINUTE, 0);
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 1);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Calendar today = Calendar.getInstance();
            long diff = calendar.getTimeInMillis() - today.getTimeInMillis();
            long days = (diff / (24 * 60 * 60 * 1000)) + 1;//result in millis
            hari = Integer.parseInt(String.valueOf(days))*-1;
        }

        // function untuk menghitung hari dan menentukan warna berdasarkan progres bimbingan
        switch (mahasiswa.getProgres()) {
            case "Proposal":
                if (hari <= 30) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#16c79a"));
                } else if (hari <= 60) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ffd56b"));
                } else {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ef4f4f"));
                }
                break;
            case "Hasil":
                if (hari <= 60) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#16c79a"));
                } else if (hari <= 90) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ffd56b"));
                } else {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ef4f4f"));
                }
                break;
            case "Sidang":
                if (hari <= 30) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#16c79a"));
                } else if (hari <= 45) {
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ffd56b"));
                } else{
                    holder.cvItemBimbing.setCardBackgroundColor(Color.parseColor("#ef4f4f"));
                }
                break;
        }

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.ic_images_src);
        requestOptions.error(R.drawable.ic_images_src);
        String url_image = "https://dataskripsi.000webhostapp.com/e_skripsi/images/";
        String npm = String.valueOf(mahasiswa.getNpm());
        Glide.with(holder.itemView.getContext())
                .load(url_image +mahasiswa.getFoto())
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true)
                .apply(requestOptions)
                .into(holder.imageView);
        holder.tvNama.setText(npm);
        holder.tvJudul.setText(mahasiswa.getNama());
        holder.tvWaktu.setText(mahasiswa.getJudul_skripsi());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {;
                onItemClickCallback.onItemClicked(list.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView tvNama, tvJudul, tvWaktu;
        CardView cvItemBimbing;

        GridViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.img_profile);
            tvNama = itemView.findViewById(R.id.tv_nama);
            tvJudul = itemView.findViewById(R.id.tv_judul);
            tvWaktu = itemView.findViewById(R.id.tv_waktu);
            cvItemBimbing = itemView.findViewById(R.id.cv_item_bimbing);
        }
    }
}
