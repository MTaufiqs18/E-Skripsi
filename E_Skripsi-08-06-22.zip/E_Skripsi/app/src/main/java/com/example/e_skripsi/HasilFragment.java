package com.example.e_skripsi;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.e_skripsi.adapter.MahasiswaAdapter;
import com.example.e_skripsi.model.Mahasiswa;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class HasilFragment extends Fragment {

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView tvDataKosong;
    private ProgressBar progressBar;
    private boolean loading;

    private List<Mahasiswa> listData = new ArrayList<>();
    private String url = "https://dataskripsi.000webhostapp.com/e_skripsi/Api.php?apicall=get_progres_hasil";
    private String password = "null";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_hasil, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.rc_hasil);
        progressBar = view.findViewById(R.id.progressbar);
        swipeRefreshLayout = view.findViewById(R.id.swiperefresh);
        tvDataKosong = view.findViewById(R.id.tv_data_kosong);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loading = false;
                recyclerView.setVisibility(View.GONE);
                listData.clear();
                bimbinganProposal();
                new Handler().postDelayed(new Runnable() {
                    @Override public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 2000);
            }
        });

        if (loading = true){
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }

        loading = true;
        bimbinganProposal();

    }

    private void bimbinganProposal(){
        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray jsonArray = obj.getJSONArray("success");
                            listData.clear();
                            if (jsonArray.length()>0) {
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject objMahasiswa = jsonArray.getJSONObject(i);

                                    Mahasiswa mahasiswa = new Mahasiswa(
                                            objMahasiswa.getInt("npm"),
                                            objMahasiswa.getString("nama"),
                                            objMahasiswa.getString("email"),
                                            objMahasiswa.getString("telp"),
                                            password,
                                            objMahasiswa.getString("foto"),
                                            objMahasiswa.getString("judul_skripsi"),
                                            objMahasiswa.getString("pembimbing_utama"),
                                            objMahasiswa.getString("pembimbing_kedua"),
                                            objMahasiswa.getString("progres"),
                                            objMahasiswa.getString("tgl_progres")
                                    );
                                    listData.add(mahasiswa);
                                }
                                recyclerView.setVisibility(View.VISIBLE);
                            }else {
                                tvDataKosong.setVisibility(View.VISIBLE);
                                recyclerView.setVisibility(View.GONE);
                            }

                            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                            MahasiswaAdapter adapter = new MahasiswaAdapter(getContext(), listData);
                            recyclerView.setAdapter(adapter);
                            adapter.setOnItemClickCallback(new MahasiswaAdapter.OnItemClickCallback() {
                                @Override
                                public void onItemClicked(Mahasiswa data) {
                                    Intent intent = new Intent(getContext(), DetailMahasiswaBimActivity.class);
                                    intent.putExtra(DetailMahasiswaBimActivity.PROFILE, data);
                                    startActivity(intent);
                                }
                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                    }
                }) {

            @Override
            public Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("pembimbing_utama", String.valueOf(SharedPrefManager.getInstance(getContext()).getDosen().getNip()));
                params.put("pembimbing_kedua", String.valueOf(SharedPrefManager.getInstance(getContext()).getDosen().getNip()));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Objects.requireNonNull(getContext()));
        requestQueue.add(stringRequest);
    }

}